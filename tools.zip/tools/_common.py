"""Zajedničko za alate: nađi sustav, biblioteku cockz i ključeve."""
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.join(BASE, "COCKYOS", "1")                       # "/" particije
SYSTEM = os.path.join(ROOT, "usr", "lib", "cockyos")
LIB = os.path.join(ROOT, "usr", "lib")
KEYS_DIR = os.path.join(BASE, "tools", "keys")
OFFICIAL_KEY = os.path.join(KEYS_DIR, "official.key")
for _p in (SYSTEM, LIB):
    sys.path.insert(0, _p)

import cockz  # noqa: E402  (biblioteka iz /usr/lib/cockz)
from cockz import keys as trust  # noqa: E402,F401


def load_seed(path):
    try:
        return trust.load_private(path)
    except trust.TrustError as e:
        raise SystemExit("error: %s (%s)" % (e, path))


def default_key():
    return OFFICIAL_KEY if os.path.isfile(OFFICIAL_KEY) else None
