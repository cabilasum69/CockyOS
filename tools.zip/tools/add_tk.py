"""Dodaje Tcl/Tk (tkinter) u runtime/windows-x64, jer ga 'embeddable' Python nema.

    python tools/add_tk.py                      (traži instalirani Python 3.15 preko `py -3.15`)
    python tools/add_tk.py "C:\\Path\\To\\Python315"   (ili zadaj mapu običnog Pythona 3.15.x)

Kopira iz tvog običnog Pythona:  _tkinter.pyd, tcl86t.dll, tk86t.dll (iz DLLs/), mapu tcl/ (tcl8.6, tk8.6...)
i paket tkinter/ (iz Lib/). Verzija običnog Pythona mora biti ista (3.15.x) kao u runtime/.
Pokreni ga s BILO KOJIM Pythonom - on samo kopira datoteke.
"""
import os
import shutil
import subprocess
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUNTIME = os.path.join(BASE, "runtime", "windows-x64")


def find_python_dir(arg):
    if arg:
        return arg
    for cmd in (["py", "-3.15", "-c", "import sys;print(sys.base_prefix)"],
                ["python", "-c", "import sys;print(sys.base_prefix)"]):
        try:
            out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL).decode().strip()
            if out and os.path.isdir(os.path.join(out, "DLLs")):
                return out
        except (OSError, subprocess.CalledProcessError):
            continue
    return None


def main():
    src = find_python_dir(sys.argv[1] if len(sys.argv) > 1 else None)
    if not src or not os.path.isdir(src):
        raise SystemExit("Could not find a normal Python 3.15 install. Pass its folder as the argument.")
    dlls, lib, tcl = (os.path.join(src, "DLLs"), os.path.join(src, "Lib"), os.path.join(src, "tcl"))
    need = [os.path.join(dlls, "_tkinter.pyd"), os.path.join(lib, "tkinter"), tcl]
    missing = [p for p in need if not os.path.exists(p)]
    if missing:
        raise SystemExit("This Python has no Tcl/Tk (missing: %s). Reinstall it with 'tcl/tk and IDLE' ticked." % missing[0])
    if not os.path.isdir(RUNTIME):
        raise SystemExit("runtime/windows-x64 not found next to tools/.")

    print("Copying Tcl/Tk from %s into %s" % (src, RUNTIME))
    for name in os.listdir(dlls):
        if name.lower() in ("_tkinter.pyd", "tcl86t.dll", "tk86t.dll", "zlib1.dll") or name.lower().startswith(("tcl", "tk")):
            shutil.copy2(os.path.join(dlls, name), RUNTIME)
            print("  dll  %s" % name)
    shutil.rmtree(os.path.join(RUNTIME, "tcl"), ignore_errors=True)
    shutil.copytree(tcl, os.path.join(RUNTIME, "tcl"))
    print("  dir  tcl/")
    shutil.rmtree(os.path.join(RUNTIME, "tkinter"), ignore_errors=True)
    shutil.copytree(os.path.join(lib, "tkinter"), os.path.join(RUNTIME, "tkinter"),
                    ignore=shutil.ignore_patterns("__pycache__", "test", "tests"))
    print("  dir  tkinter/")
    print("Done. Test:  runtime\\windows-x64\\python.exe -c \"import tkinter; print(tkinter.TkVersion)\"")


if __name__ == "__main__":
    main()
