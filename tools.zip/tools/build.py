"""Gradi release:   python tools/build.py

  1. pakira app_src/<ime>/ u potpisane .cockz (potpis: tools/keys/official.key)
        zadano -> COCKYOS/1/usr/bin/            (instalirano)
        STORE_APPS -> COCKYOS/1/usr/share/store/ (dostupno u cockStore-u)
  2. dist/CockyOS_v3_windows-x64.zip  - OS + Python (runtime/windows-x64), launcher boot.bat
     dist/CockyOS_v3_linux-macos.zip  - OS bez Pythona (koristi sistemski), launcher boot.sh
     (bez korisnika, logova, cachea, __pycache__ i TAJNIH ključeva)
  3. dist/sys.zip  - usr/ (kernel, cockz, aplikacije, store) + etc/trust.d (to Recovery Mode skida; bez lozinki i dozvola)

Privatni ključ tools/keys/official.key NIKAD ne ide u zip. Bez njega build ne radi (python tools/cockz.py keygen official).
"""
import os
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import BASE, ROOT, OFFICIAL_KEY  # noqa: E402
from pack_app import pack  # noqa: E402

DIST = os.path.join(BASE, "dist")
VERSION_TAG = "v3.1"
STORE_APPS = {"cockcalc", "cocknotes"}

SKIP_DIR_NAMES = {"__pycache__", "dist", "COCKYCACHE", "COCKBOOT_LOG", ".git"}
SKIP_DIR_CONTENTS = {os.path.join(ROOT, d) for d in ("home", "root", "tmp", "var/log", "var/run", "var/lib/cockyos")} | {
    os.path.join(BASE, "LEGACY_COCKYOS", "COCKYOS_PAR", "users")}
SKIP_FILES = {"boot_failures_log.txt", "sys.zip", "perms.json", "shadow"}
SKIP_SUFFIX = (".pyc", ".pyo", ".part", ".key")
EMPTY_DIRS = ("home", "tmp", "opt", "mnt", "var/log", "var/run", "var/lib/cockyos", "usr/lib/modules")


def build_apps():
    if not os.path.isfile(OFFICIAL_KEY):
        raise SystemExit("error: %s not found. Create it:  python tools/cockz.py keygen official\n"
                         "(then copy keys/official.pub to COCKYOS/1/COCKYOS_PAR/trust/official.pub with \"level\": \"official\")"
                         % OFFICIAL_KEY)
    apps_dir, store_dir = os.path.join(ROOT, "usr", "bin"), os.path.join(ROOT, "usr", "share", "store")
    for d in (apps_dir, store_dir):
        os.makedirs(d, exist_ok=True)
        for f in os.listdir(d):
            if f.endswith((".cockz", ".capp")):
                os.remove(os.path.join(d, f))
    src = os.path.join(BASE, "app_src")
    for name in sorted(os.listdir(src)):
        folder = os.path.join(src, name)
        if os.path.isfile(os.path.join(folder, "app.json")):
            dest = store_dir if name in STORE_APPS else apps_dir
            out, count, signed = pack(folder, dest)
            print("  app  %-14s %2d files  -> %s%s" % (name, count, os.path.basename(dest), "" if signed else "  UNSIGNED"))


TARGETS = {
    "windows-x64": {"runtime": "windows-x64", "launcher": "boot.bat"},
    "linux-macos": {"runtime": None, "launcher": "boot.sh"},
}


def iter_release_files(target):
    t = TARGETS[target]
    runtime_root = os.path.join(BASE, "runtime")
    for base, dirs, names in os.walk(BASE):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIR_NAMES)
        if os.path.abspath(base) == runtime_root:
            dirs[:] = [d for d in dirs if d == t["runtime"]]
        if os.path.abspath(base) in SKIP_DIR_CONTENTS:
            dirs[:] = []
            continue
        for n in sorted(names):
            if n in SKIP_FILES or n.endswith(SKIP_SUFFIX):
                continue
            if os.path.abspath(base) == BASE and n in ("boot.bat", "boot.sh") and n != t["launcher"]:
                continue
            full = os.path.join(base, n)
            yield os.path.relpath(full, BASE).replace(os.sep, "/"), full


def write_zip(path, entries):
    count = 0
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        if path.endswith(("windows-x64.zip", "linux-macos.zip")):
            for d in EMPTY_DIRS:
                z.writestr("COCKYOS/1/" + d + "/", "")
        for arcname, full in entries:
            assert not arcname.endswith(".key"), "private key in release!"
            z.write(full, arcname)
            count += 1
    print("  zip  %s  (%d files, %.1f KB)" % (os.path.relpath(path, BASE), count, os.path.getsize(path) / 1024.0))


def main():
    os.makedirs(DIST, exist_ok=True)
    print("Building apps...")
    build_apps()
    print("Building zips...")
    for target in TARGETS:
        write_zip(os.path.join(DIST, "CockyOS_%s_%s.zip" % (VERSION_TAG, target)), iter_release_files(target))
    sys_entries = []
    for part in ("usr", os.path.join("etc", "trust.d")):
        for base, dirs, names in os.walk(os.path.join(ROOT, part)):
            dirs[:] = sorted(d for d in dirs if d != "__pycache__")
            for n in sorted(names):
                if not n.endswith(SKIP_SUFFIX):
                    full = os.path.join(base, n)
                    sys_entries.append((os.path.relpath(full, ROOT).replace(os.sep, "/"), full))
    write_zip(os.path.join(DIST, "sys.zip"), sys_entries)


if __name__ == "__main__":
    main()
