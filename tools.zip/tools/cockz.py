"""Tanki omotač oko biblioteke /usr/lib/cockz (isto što i `python -m cockz`, ali radi iz bilo koje mape):

    python tools/cockz.py info|list|verify|unpack|export-zip|pack|keygen ...      (python tools/cockz.py help)

keygen bez mape sprema u tools/keys/.  Skriptu za raspakiravanje možeš pozvati i izravno:
    python COCKYOS/1/usr/lib/cockz/unpack.py paket.cockz [mapa]
"""
import sys

from _common import KEYS_DIR, cockz  # noqa: F401  (stavlja usr/lib na sys.path)
from cockz.__main__ import main

if __name__ == "__main__":
    argv = sys.argv[1:]
    if argv and argv[0] == "keygen" and len(argv) == 2:
        argv.append(KEYS_DIR)
    sys.exit(main(argv))
