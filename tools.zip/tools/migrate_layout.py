"""Seli staru instalaciju (v3.0: COCKYOS_PAR/users/...) u novi Linux-stil raspored (v3.1).

    python tools/migrate_layout.py <stari COCKYOS_PAR> [--dry-run]

Što radi (ništa ne briše u starom, samo kopira):
    COCKYOS_PAR/users/<u>/stuff/*            ->  /home/<u>/        (root: /root/)
    COCKYOS_PAR/users/<u>/password.txt       ->  /etc/shadow        (PBKDF2 hash umjesto čistog teksta)
    COCKYOS_PAR/users/<u>/appdata/<app>/     ->  ~/.local/share/<app>/
    COCKYOS_PAR/trust/*.pub (osim official)  ->  /etc/trust.d/
    COCKYOS_PAR/perms.json                   ->  /etc/perms.json
    COCKYOS_PAR/libs/*.cockz                 ->  /usr/lib/modules/
    COCKYOS_PAR/logs/*                       ->  /var/log/
Postojeće datoteke u novom rasporedu se ne prepisuju.
"""
import os
import shutil
import sys

from _common import ROOT, SYSTEM  # noqa: F401  (stavlja kernel na sys.path)

from kernel import users  # noqa: E402


def copy_tree(src, dst, dry, counter):
    for base, dirs, names in os.walk(src):
        rel = os.path.relpath(base, src)
        target = os.path.normpath(os.path.join(dst, rel))
        if not dry:
            os.makedirs(target, exist_ok=True)
        for n in names:
            t = os.path.join(target, n)
            if os.path.exists(t):
                continue
            counter[0] += 1
            if not dry:
                shutil.copy2(os.path.join(base, n), t)


def main(argv):
    dry = "--dry-run" in argv
    args = [a for a in argv if not a.startswith("--")]
    if len(args) != 1 or not os.path.isdir(os.path.join(args[0], "users")):
        print(__doc__)
        return 2
    old = os.path.abspath(args[0])
    new = ROOT
    counter = [0]
    shadow = {}
    print("%s %s  ->  %s" % ("DRY RUN:" if dry else "Migrating", old, new))

    for name in sorted(os.listdir(os.path.join(old, "users"))):
        udir = os.path.join(old, "users", name)
        if not os.path.isdir(udir) or not users.valid_name(name):
            continue
        home = os.path.join(new, "root") if users.is_admin(name) else os.path.join(new, "home", name)
        print(" user %-12s -> %s" % (name, os.path.relpath(home, new)))
        if not dry:
            os.makedirs(os.path.join(home, ".config"), exist_ok=True)
            os.makedirs(os.path.join(home, ".local", "share"), exist_ok=True)
        stuff = os.path.join(udir, "stuff")
        if os.path.isdir(stuff):
            copy_tree(stuff, home, dry, counter)
        appdata = os.path.join(udir, "appdata")
        if os.path.isdir(appdata):
            copy_tree(appdata, os.path.join(home, ".local", "share"), dry, counter)
        pw = os.path.join(udir, "password.txt")
        if os.path.isfile(pw):
            with open(pw, encoding="utf-8") as f:
                shadow[name] = users.hash_password(f.read().strip())

    if shadow and not dry:
        etc_shadow = os.path.join(new, "etc", "shadow")
        os.makedirs(os.path.dirname(etc_shadow), exist_ok=True)
        existing = {}
        if os.path.isfile(etc_shadow):
            for line in open(etc_shadow, encoding="utf-8"):
                u, _, h = line.rstrip("\n").partition(":")
                if u:
                    existing[u] = h
        for u, h in shadow.items():
            existing.setdefault(u, h)
        with open(etc_shadow, "w", encoding="utf-8") as f:
            for u in sorted(existing):
                f.write("%s:%s\n" % (u, existing[u]))
        try:
            os.chmod(etc_shadow, 0o600)
        except OSError:
            pass
    print(" passwords hashed: %d" % len(shadow))

    for sub, dst in (("trust", "etc/trust.d"), ("libs", "usr/lib/modules"), ("logs", "var/log")):
        s = os.path.join(old, sub)
        if os.path.isdir(s):
            if sub == "trust":                                      # official.pub dolazi s novim OS-om
                for n in os.listdir(s):
                    if n.endswith(".pub") and n != "official.pub" and not os.path.exists(os.path.join(new, dst, n)):
                        counter[0] += 1
                        if not dry:
                            os.makedirs(os.path.join(new, dst), exist_ok=True)
                            shutil.copy2(os.path.join(s, n), os.path.join(new, dst, n))
            else:
                copy_tree(s, os.path.join(new, dst), dry, counter)
    g = os.path.join(old, "perms.json")
    if os.path.isfile(g) and not os.path.exists(os.path.join(new, "etc", "perms.json")):
        counter[0] += 1
        if not dry:
            os.makedirs(os.path.join(new, "etc"), exist_ok=True)
            shutil.copy2(g, os.path.join(new, "etc", "perms.json"))
    print("Done: %d file(s) %s." % (counter[0], "would be copied" if dry else "copied"))
    print("The old folder was NOT changed. Delete it yourself when you have checked everything.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
