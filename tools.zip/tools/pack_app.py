"""Pakira folder aplikacije u potpisani .cockz:

    python tools/pack_app.py app_src/hello [-o izlazni_folder] [--key X.key] [--unsigned]

Bez --key koristi tools/keys/official.key. Isti sadržaj uvijek daje identičan paket.
"""
import argparse
import json
import os
import sys

from _common import cockz, default_key, load_seed

EXT = cockz.EXT


def pack(app_folder, out_dir, key_path="auto"):
    app_folder = os.path.abspath(app_folder)
    mp = os.path.join(app_folder, "app.json")
    if not os.path.isfile(mp):
        raise SystemExit("error: %s has no app.json" % app_folder)
    with open(mp, encoding="utf-8") as f:
        manifest = json.load(f)
    if not manifest.get("id"):
        raise SystemExit("error: app.json needs an 'id'")
    if not os.path.isfile(os.path.join(app_folder, manifest.get("entry", "main.py"))):
        raise SystemExit("error: entry file not found")
    if key_path == "auto":
        key_path = default_key()
    seed = load_seed(key_path) if key_path else None
    out = os.path.join(out_dir, manifest["id"] + EXT)
    try:
        n = cockz.pack(app_folder, out, seed)
    except cockz.CockzError as e:
        raise SystemExit("error: %s" % e)
    return out, n, bool(seed)


def main():
    ap = argparse.ArgumentParser(description="Pack a CockyOS app folder into a signed .cockz")
    ap.add_argument("folder")
    ap.add_argument("-o", "--out", default=".")
    ap.add_argument("--key", help="private key file (default: tools/keys/official.key)")
    ap.add_argument("--unsigned", action="store_true")
    a = ap.parse_args()
    out, n, signed = pack(a.folder, a.out, None if a.unsigned else (a.key or "auto"))
    print("Packed %d files -> %s (%s)" % (n, out, "signed" if signed else "UNSIGNED"))


if __name__ == "__main__":
    sys.exit(main())
