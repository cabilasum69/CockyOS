"""Pretvara Python wheel (npr. Pillow) u potpisani lib za CockyOS.

    python tools/wheel2cockz.py pillow-12.0.0-cp315-cp315-win_amd64.whl [--key tools/keys/official.key]

Rezultat: COCKYOS/1/usr/lib/modules/pillow.cockz  (OS ga pri bootu sam učita ako je potpisan povjerenim ključem).
Wheel mora odgovarati Pythonu u runtime/ (cp315 = Python 3.15, win_amd64 = 64-bitni Windows) ili biti abi3.
"""
import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile

from _common import BASE, ROOT, cockz, default_key, load_seed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("wheel")
    ap.add_argument("--key", default=None)
    ap.add_argument("--out", default=os.path.join(ROOT, "usr", "lib", "modules"))
    a = ap.parse_args()

    name = os.path.basename(a.wheel)
    m = re.match(r"^([A-Za-z0-9_.]+)-([^-]+)-([^-]+)-([^-]+)-([^-]+)\.whl$", name)
    if not m:
        raise SystemExit("error: '%s' does not look like a wheel (.whl)" % name)
    dist, version, pytag, abitag, plat = m.groups()
    lib_id = re.sub(r"[^a-z0-9_-]", "-", dist.lower())[:32]
    print("Wheel: %s %s  (python %s, abi %s, platform %s)" % (dist, version, pytag, abitag, plat))
    if plat not in ("any",) and not plat.startswith("win"):
        print("WARNING: platform '%s' is not Windows; it will not work with runtime/windows-x64." % plat)

    key = a.key or default_key()
    if not key:
        raise SystemExit("error: no signing key. Put tools/keys/official.key in place or pass --key.")
    seed = load_seed(key)

    tmp = tempfile.mkdtemp(prefix="wheel2cockz_")
    try:
        with zipfile.ZipFile(a.wheel) as z:
            base = os.path.realpath(tmp)
            for member in z.infolist():
                target = os.path.realpath(os.path.join(tmp, member.filename))
                if os.path.commonpath([base, target]) != base:
                    raise SystemExit("error: unsafe path in wheel: %s" % member.filename)
            z.extractall(tmp)
        with open(os.path.join(tmp, "lib.json"), "w", encoding="utf-8") as f:
            json.dump({"id": lib_id, "name": dist, "version": version, "path": "",
                       "source": name}, f, indent=2)
        os.makedirs(a.out, exist_ok=True)
        out = os.path.join(a.out, lib_id + cockz.EXT)
        n = cockz.pack(tmp, out, seed, kind="lib")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("Wrote %s (%d files, signed). Restart CockyOS to load it." % (out, n))


if __name__ == "__main__":
    sys.exit(main())
