runtime/ - Python koji CockyOS nosi sa sobom, jedna mapa po OS-u i arhitekturi:

    runtime/windows-x64/     Python 3.15.2 embeddable (python.org, SHA-256 d012f3aa29cf07436dae8aea1fec0fd195c2612a0b059b1f915ae0afb9ad1f62)
    runtime/linux-x64/       (nije priložen - boot.sh koristi sistemski python3)
    runtime/macos-arm64/     (nije priložen - boot.sh koristi sistemski python3)

Launcher (boot.bat / boot.sh) traži runtime/<os>-<arh>/ i koristi ga; ako ga nema, koristi Python iz sustava.
Za Linux/macOS stavi u mapu običan Python tako da postoji runtime/<os>-<arh>/bin/python3.
Ime mape = kernel.hal.RUNTIME_ID (npr. windows-x64, linux-x64, macos-arm64).
Python je pod PSF licencom (runtime/windows-x64/LICENSE.txt).
