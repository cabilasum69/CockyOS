"""CockBoot - drugi stupanj dizanja. CockLoader ga pokreće, a on diže kernel i system.py."""
import os
import subprocess
import sys
import time
import traceback
import urllib.request
import zipfile

# /boot/CockBoot.py  ->  ROOT = korijen particije ("/")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SYSTEM = os.path.join(ROOT, "usr", "lib", "cockyos")        # kernel/, sys/, helpers/, runapp.py
LIB = os.path.join(ROOT, "usr", "lib")                      # cockz/, modules/
for _p in (SYSTEM, os.path.join(SYSTEM, "sys"), LIB):       # embeddable Python (._pth) ne dodaje putanje sam
    if _p not in sys.path:
        sys.path.insert(0, _p)
SYSTEM_FILE = os.path.join(SYSTEM, "sys", "system.py")
KERNEL_FILE = os.path.join(SYSTEM, "kernel", "__init__.py")
COCKZ_FILE = os.path.join(LIB, "cockz", "__init__.py")
os.makedirs(os.path.join(ROOT, "var", "log"), exist_ok=True)
BOOT_FAIL_LOG = os.path.join(ROOT, "var", "log", "boot_failures_log.txt")

RECOVERY_URL = "https://cockyosrec.pages.dev/sys.zip"   # zip s usr/, etc/trust.d/ ... (tools/build.py ga pravi)
ZIP_PATH = os.path.join(ROOT, "tmp", "sys.zip")


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def log_error(e):
    with open(BOOT_FAIL_LOG, "a", encoding="utf-8") as f:
        f.write(time.strftime("[%Y-%m-%d %H:%M:%S] "))
        f.write("CRASH: " + str(e) + "\n")
        f.write(traceback.format_exc() + "\n\n")


def boot_animation():
    start = time.time()
    while time.time() - start < 3:
        for dots in range(1, 4):
            sys.stdout.write("\rStarting CockyOS" + "." * dots + "   ")
            sys.stdout.flush()
            time.sleep(0.4)
    clear()


def safe_extract(zip_path, dest):
    """extractall, ali odbija putanje koje bi izašle iz dest foldera."""
    base = os.path.realpath(dest)
    with zipfile.ZipFile(zip_path, "r") as z:
        for member in z.infolist():
            target = os.path.realpath(os.path.join(dest, member.filename))
            if os.path.commonpath([base, target]) != base:
                raise RuntimeError("Unsafe path in recovery zip: " + member.filename)
        z.extractall(dest)


def recovery_mode():
    print("!!! SYSTEM FILES MISSING !!!")
    choice = input("Enter Recovery Mode and download system? (y/n): ").lower()
    if choice != "y":
        print("Cannot continue without system.")
        sys.exit(1)

    print("\nEntering Recovery Mode...")
    time.sleep(1)
    print("Downloading system...")
    os.makedirs(os.path.dirname(ZIP_PATH), exist_ok=True)
    try:
        urllib.request.urlretrieve(RECOVERY_URL, ZIP_PATH)
        print("Download complete.\nInstalling system...")
        safe_extract(ZIP_PATH, ROOT)
        os.remove(ZIP_PATH)
        print("System installed successfully!")
        time.sleep(1)
        print("Rebooting...\n")
        time.sleep(1)
        sys.exit(subprocess.call([sys.executable] + sys.argv))
    except Exception as e:
        print("Recovery failed:", e)
        log_error(e)
        sys.exit(1)


# ---- MAIN BOOT ----
try:
    if "--verbose" in sys.argv:
        os.environ["COCKY_VERBOSE"] = "1"

    boot_animation()

    if not (os.path.exists(SYSTEM_FILE) and os.path.exists(KERNEL_FILE) and os.path.exists(COCKZ_FILE)):
        recovery_mode()

    from system import start_system
    start_system()

except SystemExit:
    raise
except Exception as e:
    print("Crash detected! Logging to boot_failures_log.txt")
    log_error(e)
    input("\nPress Enter to exit...")
