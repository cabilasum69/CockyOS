"""Ključevi i povjerenje za .cockz - bez ovisnosti o kernelu (radi i kao samostalna biblioteka).

Format .pub:  {"name": "ime", "public": "<64 hex znaka>", "level": "official" | "trusted"}
Format .key (privatni, čuvaj ga!):  {"name": "ime", "private": "<64 hex>", "public": "<64 hex>"}
Povjerenje = mapa s *.pub datotekama (OS: /etc/trust.d). Samo datoteka official.pub može imati level "official".
"""
import json
import os
import re

from . import ed25519

_NAME_RE = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,31}")


class TrustError(Exception):
    pass


def trusted_keys(trust_dir):
    """{javni_hex: {"name", "level", "file"}} za sve valjane .pub datoteke u trust_dir."""
    out = {}
    if not trust_dir or not os.path.isdir(trust_dir):
        return out
    for fname in sorted(os.listdir(trust_dir)):
        if not fname.endswith(".pub"):
            continue
        try:
            with open(os.path.join(trust_dir, fname), encoding="utf-8") as f:
                d = json.load(f)
            pub = str(d["public"]).lower()
            bytes.fromhex(pub)
            if len(pub) != 64:
                continue
            level = "official" if (d.get("level") == "official" and fname == "official.pub") else "trusted"
            out[pub] = {"name": str(d.get("name", fname[:-4])), "level": level, "file": fname}
        except (OSError, ValueError, KeyError, TypeError):
            continue
    return out


def add_key(trust_dir, name, pub_hex):
    """Dodaje ključ kao 'trusted' (nikad kao 'official')."""
    if not _NAME_RE.fullmatch(name or "") or name == "official":
        raise TrustError("Invalid key name.")
    pub_hex = pub_hex.strip().lower()
    if len(pub_hex) != 64:
        raise TrustError("Public key must be 64 hex characters.")
    try:
        bytes.fromhex(pub_hex)
    except ValueError:
        raise TrustError("Public key is not hex.")
    os.makedirs(trust_dir, exist_ok=True)
    with open(os.path.join(trust_dir, name + ".pub"), "w", encoding="utf-8") as f:
        json.dump({"name": name, "public": pub_hex, "level": "trusted"}, f, indent=2)
    return name


def remove_key(trust_dir, name):
    if name == "official":
        raise TrustError("The official key can't be removed.")
    path = os.path.join(trust_dir, name + ".pub")
    if not _NAME_RE.fullmatch(name or "") or not os.path.isfile(path):
        raise TrustError("No such key.")
    os.remove(path)


def read_pub_file(path):
    """Čita .pub ili .key datoteku i vraća (ime, javni_hex)."""
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        pub = str(d["public"]).lower()
        bytes.fromhex(pub)
    except (OSError, ValueError, KeyError, TypeError):
        raise TrustError("Not a valid key file.")
    if len(pub) != 64:
        raise TrustError("Not a valid key file.")
    return str(d.get("name", os.path.splitext(os.path.basename(path))[0])), pub


def generate_keypair(name, out_dir):
    """Pravi <name>.key (privatni) i <name>.pub u out_dir. Vraća (key_path, pub_path)."""
    if not _NAME_RE.fullmatch(name or ""):
        raise TrustError("Invalid key name (letters, numbers, _ . -).")
    seed, pub = ed25519.generate()
    os.makedirs(out_dir, exist_ok=True)
    kp, pp = os.path.join(out_dir, name + ".key"), os.path.join(out_dir, name + ".pub")
    for p in (kp, pp):
        if os.path.exists(p):
            raise TrustError("%s already exists." % os.path.basename(p))
    with open(kp, "w", encoding="utf-8") as f:
        json.dump({"name": name, "private": seed.hex(), "public": pub.hex()}, f, indent=2)
    with open(pp, "w", encoding="utf-8") as f:
        json.dump({"name": name, "public": pub.hex(), "level": "trusted"}, f, indent=2)
    try:
        os.chmod(kp, 0o600)
    except OSError:
        pass
    return kp, pp


def load_private(path):
    """Čita .key datoteku i vraća 32-bajtni seed."""
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        seed = bytes.fromhex(d["private"])
    except (OSError, ValueError, KeyError, TypeError):
        raise TrustError("Not a valid .key file.")
    if len(seed) != 32 or ed25519.public_key(seed).hex() != str(d.get("public", "")).lower():
        raise TrustError("Key file is damaged (private and public key don't match).")
    return seed
