"""Pretvara .cockz u običan ZIP (za pregled u 7-Zipu i sl.). Hashevi svih datoteka se provjeravaju PRIJE pisanja.
Zip NEMA potpis: služi samo za pregled, ne za instalaciju."""
import os
import zipfile

from ._format import open_package, CockzError


def export_zip(cockz_path, zip_path):
    pkg = open_package(cockz_path)
    pkg.verify_all()                                   # loš paket ne postaje zip
    tmp = zip_path + ".part"
    with open(cockz_path, "rb") as src, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for e in pkg.files:
            z.writestr(e["path"], pkg._read_entry(src, e))
        z.writestr("_cockz_info.txt", "Exported from %s\nkind: %s\nUNSIGNED copy - for viewing only.\n"
                   % (os.path.basename(cockz_path), pkg.kind))
    os.replace(tmp, zip_path)
    return len(pkg.files)
