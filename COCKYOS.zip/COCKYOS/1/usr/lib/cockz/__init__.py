"""cockz - biblioteka za .cockz pakete (čitanje, pakiranje, potpisi, raspakiravanje).

    import cockz
    pkg = cockz.open_package("app.cockz"); pkg.verify(keys); pkg.extract("mapa")
    cockz.pack("mapa", "app.cockz", seed)
    cockz.keys / cockz.ed25519 / cockz.export_zip

Samostalna je: ne treba CockyOS kernel. Kao alat:  python -m cockz <naredba>   ili   python unpack.py <paket> [mapa]
"""
from ._format import *            # noqa: F401,F403
from ._format import (EXT, MAGIC, SIG_MAGIC, SIG_LEN, STATUS_OFFICIAL, STATUS_TRUSTED, STATUS_UNKNOWN,  # noqa: F401
                      STATUS_UNSIGNED, STATUS_BAD, CockzError, Package, Verification, open_package, pack,
                      key_id, safe_member)
from . import ed25519, keys       # noqa: F401
from .zipexport import export_zip  # noqa: F401
from .keys import TrustError       # noqa: F401

__version__ = "1.0"
