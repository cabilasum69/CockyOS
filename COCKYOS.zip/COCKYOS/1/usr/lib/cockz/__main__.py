"""python -m cockz <naredba>   (stavi usr/lib u PYTHONPATH ili pokreni iz usr/lib)

    info <paket>                      vrsta, potpis, dozvole, datoteke
    list <paket>
    verify <paket> [--trust MAPA]     potpis + hash svake datoteke (exit 0 samo ako je pouzdan)
    unpack <paket> [mapa] [--force]
    export-zip <paket> [izlaz.zip]    običan zip za pregled (bez potpisa)
    pack <mapa> [izlaz.cockz] [--key X.key]
    keygen <ime> [mapa]
"""
import os
import sys

import cockz
from cockz.unpack import find_trust_dir, main as unpack_main


def _keys(args):
    trust = None
    if "--trust" in args:
        i = args.index("--trust")
        trust = args[i + 1]
        del args[i:i + 2]
    return cockz.keys.trusted_keys(trust or find_trust_dir(os.getcwd()) or find_trust_dir(os.path.dirname(__file__)))


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 2
    cmd, args = argv[0], list(argv[1:])
    try:
        if cmd == "unpack":
            return unpack_main(args)
        if cmd == "keygen":
            kp, pp = cockz.keys.generate_keypair(args[0], args[1] if len(args) > 1 else ".")
            print("Private key (KEEP SECRET): %s\nPublic key : %s" % (kp, pp))
        elif cmd == "pack":
            key = None
            if "--key" in args:
                i = args.index("--key")
                key = cockz.keys.load_private(args[i + 1])
                del args[i:i + 2]
            out = args[1] if len(args) > 1 else os.path.basename(os.path.abspath(args[0])) + cockz.EXT
            n = cockz.pack(args[0], out, key)
            print("Packed %d files -> %s (%s)" % (n, out, "signed" if key else "UNSIGNED"))
        elif cmd == "export-zip":
            out = args[1] if len(args) > 1 else os.path.splitext(args[0])[0] + ".zip"
            print("Exported %d files -> %s (no signature; for viewing only)" % (cockz.export_zip(args[0], out), out))
        elif cmd in ("info", "list", "verify"):
            keys = _keys(args)
            pkg = cockz.open_package(args[0])
            ver = pkg.verify(keys)
            if cmd == "info":
                print("kind       : %s\nfiles      : %d\nsignature  : %s" % (pkg.kind, len(pkg.files), ver.describe()))
                for k in ("name", "version", "description"):
                    if pkg.meta.get(k):
                        print("%-11s: %s" % (k, pkg.meta[k]))
                if pkg.meta.get("permissions"):
                    print("permissions: %s" % ", ".join(pkg.meta["permissions"]))
            elif cmd == "list":
                for e in pkg.files:
                    print("%9d  %-8s %s" % (e["size"], e["method"], e["path"]))
            else:
                pkg.verify_all()
                print("%s: %s, all %d file hashes OK" % (args[0], ver.describe(), len(pkg.files)))
                return 0 if ver.ok else 2
        else:
            print("Unknown command '%s'.\n%s" % (cmd, __doc__))
            return 2
    except (cockz.CockzError, cockz.TrustError, OSError, IndexError) as e:
        print("error: %s" % (e if not isinstance(e, IndexError) else "missing argument"))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
