#!/usr/bin/env python3
"""Raspakiravanje (decompile) .cockz paketa - skripta iz lib/.

    python unpack.py paket.cockz [odredišna_mapa] [--force] [--trust MAPA_S_KLJUČEVIMA]

Bez odredišta raspakira u mapu s imenom paketa. Odbija paket s lošim potpisom ili hashem; nepotpisan / nepoznat ključ
traži --force. Ključevi se traže u <OS>/etc/trust.d (pronalazi se sam) ili u --trust mapi.
"""
import os
import sys

if __name__ == "__main__":                       # da radi i kao `python unpack.py` bez instalacije
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cockz                                      # noqa: E402


def find_trust_dir(start):
    d = os.path.abspath(start)
    for _ in range(8):
        cand = os.path.join(d, "etc", "trust.d")
        if os.path.isdir(cand):
            return cand
        d = os.path.dirname(d)
    return None


def unpack(path, dest=None, force=False, trust_dir=None):
    pkg = cockz.open_package(path)
    keys = cockz.keys.trusted_keys(trust_dir or find_trust_dir(os.path.dirname(os.path.abspath(path)))
                                   or find_trust_dir(os.path.dirname(os.path.abspath(__file__))))
    ver = pkg.verify(keys)
    if ver.status == cockz.STATUS_BAD:
        raise cockz.CockzError("signature check FAILED: %s" % ver.describe())
    if not ver.ok and not force:
        raise cockz.CockzError("package is %s (use --force to unpack anyway)" % ver.describe())
    dest = dest or os.path.splitext(os.path.basename(path))[0]
    return pkg.extract(dest), dest, ver


def main(argv):
    force = "--force" in argv
    trust = None
    args = [a for a in argv if a != "--force"]
    if "--trust" in args:
        i = args.index("--trust")
        trust = args[i + 1] if i + 1 < len(args) else None
        args = args[:i] + args[i + 2:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        return 2
    try:
        n, dest, ver = unpack(args[0], args[1] if len(args) > 1 else None, force, trust)
    except (cockz.CockzError, OSError) as e:
        print("error: %s" % e)
        return 1
    print("Unpacked %d files into %s  [%s]" % (n, dest, ver.describe()))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
