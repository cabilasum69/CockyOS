"""Format .cockz - CockyOS paket (aplikacija, lib ili običan arhiv) s ugrađenim potpisom.

Raspored datoteke (sve je little-endian):

    8  B   MAGIC            b"COCKZ\\x01\\x00\\x00"   (peti..sedmi bajt: verzija formata)
    4  B   header_len
    N  B   header           JSON (UTF-8): {"format":1, "kind":"app|lib|archive", "meta":{...manifest...},
                                           "files":[{"path","size","sha256","offset","stored","method"}], "payload":<bajtova>}
    M  B   payload          datoteke jedna za drugom (deflate ili store)
    -- opcionalno --
    8  B   b"COCKSIG1"
    32 B   javni ključ potpisnika (Ed25519)
    64 B   potpis nad  b"cockz-v1\\0" + SHA-256(sve prije potpisnog bloka)

Potpis pokriva i zaglavlje (manifest, dozvole, hashevi) i sve podatke, pa se svaka promjena otkriva.
Isti ulaz daje identičan paket (nema vremenskih oznaka), pa se cache ne raspakirava bez potrebe.
"""
import hashlib
import json
import os
import re
import struct
import zlib

from . import ed25519

EXT = ".cockz"
MAGIC = b"COCKZ\x01\x00\x00"
SIG_MAGIC = b"COCKSIG1"
SIG_LEN = len(SIG_MAGIC) + 32 + 64
DOMAIN = b"cockz-v1\x00"
MAX_HEADER = 8 * 1024 * 1024
MAX_UNPACKED = 400 * 1024 * 1024
MAX_FILES = 20000
SKIP_DIRS = {"__pycache__", ".git"}
SKIP_SUFFIX = (".pyc", ".pyo", ".part")

STATUS_OFFICIAL = "official"       # potpisano službenim ključem
STATUS_TRUSTED = "trusted"         # potpisano ključem kojem root vjeruje
STATUS_UNKNOWN = "untrusted"       # ispravan potpis, ali ključ nije poznat
STATUS_UNSIGNED = "unsigned"       # nema potpisa
STATUS_BAD = "bad"                 # potpis ili sadržaj ne valja


class CockzError(Exception):
    pass


def key_id(pub):
    return hashlib.sha256(pub).hexdigest()[:16]


def safe_member(name):
    n = name.replace("\\", "/")
    return bool(n) and not (n.startswith("/") or re.match(r"^[A-Za-z]:", n)
                            or ".." in n.split("/") or "\x00" in n)


class Verification(object):
    def __init__(self, status, pub=None, signer=None, detail=""):
        self.status = status
        self.pub = pub
        self.signer = signer
        self.detail = detail

    @property
    def key_id(self):
        return key_id(self.pub) if self.pub else None

    @property
    def ok(self):
        return self.status in (STATUS_OFFICIAL, STATUS_TRUSTED)

    def describe(self):
        if self.status == STATUS_UNSIGNED:
            return "UNSIGNED"
        if self.status == STATUS_BAD:
            return "BAD SIGNATURE (%s)" % self.detail
        who = "%s [%s]" % (self.signer or "unknown key", self.key_id)
        return {"official": "official: ", "trusted": "trusted: ", "untrusted": "UNTRUSTED key: "}[self.status] + who


# ---------------------------------------------------------------- čitanje
class Package(object):
    def __init__(self, path):
        self.path = path
        if not os.path.isfile(path):
            raise CockzError("File not found: %s" % path)
        self.size = os.path.getsize(path)
        with open(path, "rb") as f:
            head = f.read(12)
            if len(head) < 12 or head[:8] != MAGIC:
                raise CockzError("Not a .cockz file (bad magic).")
            hlen = struct.unpack("<I", head[8:12])[0]
            if hlen > MAX_HEADER or 12 + hlen > self.size:
                raise CockzError("Corrupt header length.")
            raw = f.read(hlen)
        try:
            self.header = json.loads(raw.decode("utf-8"))
        except ValueError:
            raise CockzError("Header is not valid JSON.")
        self._check_header(hlen)

    def _check_header(self, hlen):
        h = self.header
        if not isinstance(h, dict) or h.get("format") != 1:
            raise CockzError("Unsupported .cockz format version.")
        if h.get("kind") not in ("app", "lib", "archive"):
            raise CockzError("Unknown package kind.")
        files = h.get("files")
        payload = h.get("payload")
        if not isinstance(files, list) or not isinstance(payload, int) or payload < 0:
            raise CockzError("Malformed header.")
        if len(files) > MAX_FILES:
            raise CockzError("Too many files in package.")
        self.payload_start = 12 + hlen
        self.signed_end = self.payload_start + payload
        if self.signed_end > self.size:
            raise CockzError("File is truncated.")
        rest = self.size - self.signed_end
        if rest not in (0, SIG_LEN):
            raise CockzError("Unexpected data after payload.")
        self.has_sig = rest == SIG_LEN
        total = 0
        seen = set()
        for e in files:
            try:
                p, sz, off, st = e["path"], e["size"], e["offset"], e["stored"]
                ok = (isinstance(p, str) and isinstance(sz, int) and isinstance(off, int) and isinstance(st, int)
                      and isinstance(e["sha256"], str) and e["method"] in ("deflate", "store"))
            except (KeyError, TypeError):
                ok = False
            if not ok or sz < 0 or off < 0 or st < 0 or off + st > payload:
                raise CockzError("Malformed file entry.")
            if not safe_member(p):
                raise CockzError("Unsafe path inside package: %s" % p)
            if p.lower() in seen:
                raise CockzError("Duplicate path inside package: %s" % p)
            seen.add(p.lower())
            total += sz
        if total > MAX_UNPACKED:
            raise CockzError("Package is too big when unpacked.")

    @property
    def kind(self):
        return self.header["kind"]

    @property
    def meta(self):
        m = self.header.get("meta")
        return m if isinstance(m, dict) else {}

    @property
    def files(self):
        return self.header["files"]

    def names(self):
        return [e["path"] for e in self.files]

    def _entry(self, name):
        for e in self.files:
            if e["path"] == name:
                return e
        raise CockzError("No such file in package: %s" % name)

    def _read_entry(self, f, e):
        f.seek(self.payload_start + e["offset"])
        blob = f.read(e["stored"])
        if len(blob) != e["stored"]:
            raise CockzError("File is truncated.")
        if e["method"] == "deflate":
            try:
                d = zlib.decompressobj()
                data = d.decompress(blob, e["size"] + 1)
            except zlib.error:
                raise CockzError("Corrupt data for %s." % e["path"])
        else:
            data = blob
        if len(data) != e["size"] or hashlib.sha256(data).hexdigest() != e["sha256"]:
            raise CockzError("Hash mismatch for %s (package was modified)." % e["path"])
        return data

    def read(self, name):
        with open(self.path, "rb") as f:
            return self._read_entry(f, self._entry(name))

    def extract(self, dest):
        """Raspakira sve u dest. Svaku datoteku provjerava prema hashu."""
        os.makedirs(dest, exist_ok=True)
        base = os.path.realpath(dest)
        with open(self.path, "rb") as f:
            for e in self.files:
                target = os.path.realpath(os.path.join(dest, e["path"]))
                if os.path.commonpath([base, target]) != base:
                    raise CockzError("Unsafe path inside package: %s" % e["path"])
                data = self._read_entry(f, e)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with open(target, "wb") as out:
                    out.write(data)
        return len(self.files)

    # ---- potpis
    def digest(self):
        """SHA-256 svega što potpis pokriva (ujedno otisak paketa za cache i dozvole)."""
        h = hashlib.sha256()
        left = self.signed_end
        with open(self.path, "rb") as f:
            while left:
                chunk = f.read(min(1 << 20, left))
                if not chunk:
                    raise CockzError("File is truncated.")
                h.update(chunk)
                left -= len(chunk)
        return h.digest()

    def verify(self, trusted=None):
        """trusted: dict {javni_ključ_hex: {"name":..., "level": "official"|"trusted"}}"""
        trusted = trusted or {}
        if not self.has_sig:
            return Verification(STATUS_UNSIGNED)
        with open(self.path, "rb") as f:
            f.seek(self.signed_end)
            blk = f.read(SIG_LEN)
        if blk[:8] != SIG_MAGIC:
            return Verification(STATUS_BAD, detail="signature block damaged")
        pub, sig = blk[8:40], blk[40:]
        if not ed25519.verify(pub, DOMAIN + self.digest(), sig):
            return Verification(STATUS_BAD, pub, detail="signature does not match content")
        t = trusted.get(pub.hex())
        if t is None:
            return Verification(STATUS_UNKNOWN, pub)
        return Verification(STATUS_OFFICIAL if t.get("level") == "official" else STATUS_TRUSTED, pub, t.get("name"))

    def verify_all(self):
        """Provjeri hash svake datoteke (bez raspakiravanja). Baca CockzError ako nešto ne valja."""
        with open(self.path, "rb") as f:
            for e in self.files:
                self._read_entry(f, e)
        return True


def open_package(path):
    return Package(path)


# ---------------------------------------------------------------- pakiranje
def _collect(folder):
    out = []
    for base, dirs, names in os.walk(folder):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        for n in sorted(names):
            if n.endswith(SKIP_SUFFIX) or n.startswith("."):
                continue
            full = os.path.join(base, n)
            if os.path.islink(full):
                continue
            out.append((os.path.relpath(full, folder).replace(os.sep, "/"), full))
    out.sort()
    return out


def pack(folder, out_path, seed=None, kind=None):
    """Zapakira folder u .cockz. app.json -> kind app, lib.json -> kind lib, inače archive.
    seed: 32 bajta Ed25519 privatnog ključa (ili None = nepotpisano). Vraća broj datoteka."""
    folder = os.path.abspath(folder)
    if not os.path.isdir(folder):
        raise CockzError("Not a folder: %s" % folder)
    meta = {}
    detected = "archive"
    for fname, k in (("app.json", "app"), ("lib.json", "lib")):
        mp = os.path.join(folder, fname)
        if os.path.isfile(mp):
            try:
                with open(mp, encoding="utf-8") as f:
                    meta = json.load(f)
            except ValueError:
                raise CockzError("%s is not valid JSON." % fname)
            if not isinstance(meta, dict):
                raise CockzError("%s must contain a JSON object." % fname)
            detected = k
            break
    kind = kind or detected
    files = _collect(folder)
    if not files:
        raise CockzError("Folder is empty.")
    if len(files) > MAX_FILES:
        raise CockzError("Too many files.")

    entries, blobs, offset = [], [], 0
    for arc, full in files:
        with open(full, "rb") as f:
            data = f.read()
        comp = zlib.compress(data, 9)
        method, blob = ("deflate", comp) if len(comp) < len(data) else ("store", data)
        entries.append({"path": arc, "size": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                        "offset": offset, "stored": len(blob), "method": method})
        blobs.append(blob)
        offset += len(blob)
    header = {"format": 1, "kind": kind, "meta": meta, "files": entries, "payload": offset}
    hbytes = json.dumps(header, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    body = MAGIC + struct.pack("<I", len(hbytes)) + hbytes + b"".join(blobs)
    tail = b""
    if seed is not None:
        sig = ed25519.sign(seed, DOMAIN + hashlib.sha256(body).digest())
        tail = SIG_MAGIC + ed25519.public_key(seed) + sig
    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)
    tmp = out_path + ".part"
    with open(tmp, "wb") as f:
        f.write(body + tail)
    os.replace(tmp, out_path)
    return len(files)
