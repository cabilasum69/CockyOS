"""Guard - provodi dozvole u procesu aplikacije (PEP 578 audit hook).

Pokreće ga runapp.py PRIJE nego se izvrši ijedan red aplikacije. Hook se u Pythonu ne može maknuti.
Kontrolira: otvaranje/brisanje/preimenovanje datoteka, pokretanje programa, mrežu, ctypes/native.

  - čitanje: smije samo svoj paket, kernel/libs/runtime, sistemske mape Pythona i OS-a, i (uz dozvolu) dom korisnika
  - pisanje: smije samo svoje appdata/ i cache/tmp, i (uz fs.user.write) dom korisnika
  - /etc/shadow (lozinke) nitko ne smije čitati ni pisati osim kernela; tuđe ~/.config i ~/.local su zatvoreni
  - proc.spawn / net / native bez dozvole bacaju PermissionError

VAŽNO (poštena granica): ovo je ograda protiv slučajnih i naivnih zlouporaba, ne savršen sandbox.
Odlučan napadač s izvršavanjem proizvoljnog Python koda u istom procesu može naći zaobilaznicu.
Prava zaštita su potpisi + odobrenje dozvola: instaliraj samo pakete kojima vjeruješ.
"""
import os
import sys
import threading

_tls = threading.local()
_active = False

_SPAWN_EVENTS = {"subprocess.Popen", "os.system", "os.exec", "os.posix_spawn", "os.spawn",
                 "os.startfile", "pty.spawn", "os.fork", "os.forkpty"}
_NET_EVENTS = {"socket.connect", "socket.bind", "socket.sendto", "socket.getaddrinfo",
               "socket.gethostbyname", "socket.gethostbyaddr", "socket.getnameinfo", "socket.sendmsg"}
_NATIVE_MODULES = {"ctypes", "_ctypes", "winreg", "_winreg", "_winapi"}
_SPAWN_MODULES = {"multiprocessing", "pty"}
_WRITE_PATH_EVENTS = {"os.remove": (0,), "os.rename": (0, 1), "os.mkdir": (0,), "os.rmdir": (0,),
                      "os.chmod": (0,), "os.chown": (0,), "os.truncate": (0,), "os.symlink": (1,),
                      "os.link": (0, 1), "os.utime": (0,), "os.mkfifo": (0,), "os.mknod": (0,),
                      "shutil.copyfile": (1,), "shutil.copymode": (1,), "shutil.copystat": (1,),
                      "shutil.copytree": (1,), "shutil.rmtree": (0,), "shutil.move": (1,)}
_READ_PATH_EVENTS = {"os.listdir": 0, "os.scandir": 0, "shutil.copyfile": 0, "shutil.copytree": 0, "shutil.move": 0}


def _norm(p):
    return os.path.normcase(os.path.realpath(os.path.abspath(p)))


def _inside(path, roots):
    for r in roots:
        if path == r or path.startswith(r + os.sep):
            return True
    return False


class Denied(PermissionError):
    pass


class _Privileged(object):
    """with guard.privileged(): ...   - samo kod iz kernel/ i helpers/ smije (provjerava se datoteka pozivatelja)."""
    def __init__(self, trusted_dirs):
        self.trusted_dirs = trusted_dirs

    def __call__(self):
        if not _active:                   # bez guarda nema što zaobilaziti (shell, alati)
            return self
        fn = os.path.normcase(os.path.abspath(sys._getframe(1).f_code.co_filename))
        if not any(fn.startswith(d + os.sep) for d in self.trusted_dirs):
            raise Denied("[CockyOS guard] privileged mode is for the kernel only")
        return self

    def __enter__(self):
        _tls.depth = getattr(_tls, "depth", 0) + 1

    def __exit__(self, *a):
        _tls.depth -= 1
        return False


_trusted_dirs = []
privileged = _Privileged(_trusted_dirs)


def is_privileged():
    return getattr(_tls, "depth", 0) > 0


def active():
    return _active


def install(app_id, granted, read_roots, write_roots, stuff_dir, deny_roots=(), hidden_roots=(),
            pw_names=("shadow", "password.txt"), kernel_dirs=()):
    """Aktivira guard za ovaj proces. Nepovratno."""
    global _active
    if _active:
        raise RuntimeError("guard already installed")
    _trusted_dirs[:] = [os.path.normcase(os.path.abspath(d)) for d in kernel_dirs]
    granted = frozenset(granted)
    can_read = "fs.user.read" in granted or "fs.user.write" in granted
    can_write = "fs.user.write" in granted
    stuff = _norm(stuff_dir) if stuff_dir else None
    rroots = tuple(_norm(r) for r in read_roots if r)
    wroots = tuple(_norm(r) for r in write_roots if r)
    droots = tuple(_norm(r) for r in deny_roots if r)
    hroots = tuple(_norm(r) for r in hidden_roots if r)       # unutar doma, ali tuđe (.config, .local)
    pw = frozenset(n.lower() for n in pw_names)

    def deny(what, perm=None):
        msg = "[CockyOS guard] '%s' is not allowed to %s" % (app_id, what)
        if perm:
            msg += " (needs permission '%s')" % perm
        raise Denied(msg)

    def readable(p):
        if os.path.basename(p).lower() in pw:
            return False
        if _inside(p, wroots):
            return True
        if _inside(p, hroots):
            return False
        if stuff and can_read and _inside(p, (stuff,)):
            return True
        if _inside(p, droots):
            return False
        return _inside(p, rroots)

    def writable(p):
        if os.path.basename(p).lower() in pw:
            return False
        if _inside(p, wroots):
            return True
        if _inside(p, hroots):
            return False
        if stuff and can_write and _inside(p, (stuff,)):
            return True
        return False

    def to_path(x):
        if isinstance(x, int) or x is None:
            return None
        try:
            return _norm(os.fsdecode(x))
        except (TypeError, ValueError):
            return None

    def hook(event, args):
        if getattr(_tls, "depth", 0) > 0:
            return
        if event == "open":
            p = to_path(args[0])
            if p is None:
                return
            mode, flags = args[1], args[2] if len(args) > 2 else 0
            write = bool(mode and any(c in str(mode) for c in "wax+")) or bool(
                flags and flags & (os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC))
            if write:
                if not writable(p):
                    deny("write '%s'" % os.path.basename(p), "fs.user.write" if stuff and _inside(p, (stuff,)) else None)
            elif not readable(p):
                deny("read '%s'" % os.path.basename(p), "fs.user.read" if stuff and _inside(p, (stuff,)) else None)
        elif event in _WRITE_PATH_EVENTS:
            for i in _WRITE_PATH_EVENTS[event]:
                if i < len(args):
                    p = to_path(args[i])
                    if p is not None and not writable(p):
                        deny("change '%s'" % os.path.basename(p), "fs.user.write")
            if event in _READ_PATH_EVENTS:
                p = to_path(args[_READ_PATH_EVENTS[event]])
                if p is not None and not readable(p):
                    deny("read '%s'" % os.path.basename(p), "fs.user.read")
        elif event in _READ_PATH_EVENTS:
            p = to_path(args[_READ_PATH_EVENTS[event]])
            if p is not None and not readable(p):
                deny("list '%s'" % os.path.basename(p), "fs.user.read")
        elif event in _SPAWN_EVENTS:
            if "proc.spawn" not in granted:
                deny("start programs", "proc.spawn")
        elif event in _NET_EVENTS:
            if "net" not in granted:
                deny("use the network", "net")
        elif event == "import":
            top = str(args[0]).split(".")[0]
            if top in _NATIVE_MODULES and "native" not in granted:
                deny("import '%s'" % top, "native")
            if top in _SPAWN_MODULES and "proc.spawn" not in granted:
                deny("import '%s'" % top, "proc.spawn")

    sys.addaudithook(hook)
    _active = True


def system_read_roots():
    """Mape koje je uvijek bezopasno čitati: Python i OS (da radi import, tkinter, locale...)."""
    roots = {sys.prefix, sys.base_prefix, sys.exec_prefix, os.path.dirname(os.path.abspath(sys.executable))}
    for p in sys.path:
        if p and os.path.exists(p):
            roots.add(p)
    if os.name == "nt":
        for var in ("SystemRoot", "windir"):
            if os.environ.get(var):
                roots.add(os.environ[var])
    else:
        roots.update(["/usr", "/lib", "/lib64", "/etc", "/dev", "/opt", "/System", "/Library", "/proc/self"])
    return [r for r in roots if r and os.path.exists(r)]
