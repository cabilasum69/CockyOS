"""ctx.api - jedini službeni put kojim aplikacija traži nešto od kernela. Svaka metoda provjerava dozvolu.

    ctx.api.listdir("music")             fs.user.read     (putanje su relativne na tvoj dom /home/<ti>)
    ctx.api.read_text("a.txt")           fs.user.read
    ctx.api.write_text("a.txt", "...")   fs.user.write
    ctx.api.audio                        audio            (helpers.audio: Player, ID3 oznake)
    ctx.api.image("slika.png")           fs.user.read     (helpers.imaging: PNG/GIF/BMP, JPG uz pillow lib)
    ctx.api.sysinfo()                    sysinfo
    ctx.api.apps()                       apps.list
    ctx.api.start_app("cocktos", [..])   apps.launch
    ctx.api.install(rel_path)            apps.install     (samo root, samo potpisani paketi)
    ctx.api.trusted_keys()               -                (javni ključevi kojima OS vjeruje)
    ctx.api.verify(rel_path)             fs.user.read     (potpis + hash paketa)
    ctx.api.pack / unpack                fs.user.read + fs.user.write
"""
import os

from . import apps, cockz, guard, hal, paths, perms, trust, users

from helpers import fsx


class PermissionDenied(PermissionError):
    pass


class KernelView(object):
    """Što aplikacija smije vidjeti od kernela (ne cijeli modul)."""
    VERSION = None

    def __init__(self, ctx):
        import kernel
        self.VERSION = kernel.VERSION
        self.platform = hal.NAME
        self.runtime_id = hal.RUNTIME_ID

    @property
    def hal(self):
        return hal

    @property
    def console(self):
        from . import console
        return console

    @property
    def cockz(self):
        return cockz

    @property
    def trust(self):
        return trust

    @property
    def cock67(self):
        from . import cock67
        return cock67


class Api(object):
    def __init__(self, ctx):
        self._ctx = ctx

    # ---- dozvole
    def _need(self, perm):
        if perm not in self._ctx.permissions:
            raise PermissionDenied("[CockyOS] '%s' needs permission '%s'" % (self._ctx.id, perm))

    def _stuff(self, perm):
        self._need(perm)
        user = self._ctx.user
        if not user or not users.exists(user):
            raise PermissionDenied("No user is logged in, so there is no home folder.")
        return users.stuff_dir(user)

    def permissions(self):
        return sorted(self._ctx.permissions)

    # ---- datoteke (u tvom domu)
    def path(self, rel="", write=False, follow_last=True):
        """Prava putanja do 'rel' u tvom domu (prati linkove, ne izlazi iz doma). ~/.config i ~/.local su zatvoreni."""
        home = self._stuff("fs.user.write" if write else "fs.user.read")
        real = fsx.safe_join(home, rel, follow_last)
        top = os.path.relpath(real, os.path.realpath(home)).replace("\\", "/").split("/")[0]
        if top in users.HIDDEN_DIRS:
            raise PermissionDenied("[CockyOS] %s is private (use ctx.data_dir for your app's data)" % top)
        return real

    def listdir(self, rel=""):
        d = self.path(rel)
        if not os.path.isdir(d):
            raise FileNotFoundError("Not a folder: %s" % rel)
        items = fsx.list_dir(d, os.path.realpath(self._stuff("fs.user.read")))
        if os.path.realpath(d) == os.path.realpath(self._stuff("fs.user.read")):
            items = [i for i in items if i["name"] not in users.HIDDEN_DIRS]
        return items

    def symlink(self, target, link_rel):
        """Pravi CockyOS link (ln -s). Cilj mora ostati unutar tvog doma."""
        from . import vfs
        home = self._stuff("fs.user.write")
        base = os.path.dirname(self.path(link_rel, write=True, follow_last=False))
        t = target.replace("\\", "/")
        rel_to_jail = t.lstrip("/") if t.startswith("/") else os.path.relpath(os.path.join(base, t), os.path.realpath(home))
        vfs.resolve(home, rel_to_jail)                      # baca PermissionError ako bi izašao iz doma
        vfs.symlink(target, self.path(link_rel, write=True, follow_last=False))

    def readlink(self, rel):
        from . import vfs
        t = vfs.read_link(self.path(rel, follow_last=False))
        if t is None:
            raise OSError("Not a link: %s" % rel)
        return t

    def exists(self, rel):
        return os.path.exists(self.path(rel))

    def read_bytes(self, rel):
        with open(self.path(rel), "rb") as f:
            return f.read()

    def read_text(self, rel, encoding="utf-8"):
        with open(self.path(rel), encoding=encoding) as f:
            return f.read()

    def write_bytes(self, rel, data):
        fsx.write_atomic(self.path(rel, write=True), data)

    def write_text(self, rel, text, encoding="utf-8"):
        fsx.write_atomic(self.path(rel, write=True), text.encode(encoding))

    def mkdir(self, rel):
        os.makedirs(self.path(rel, write=True), exist_ok=True)

    def copy(self, src_rel, dst_rel):
        """Kopira datoteku ili mapu unutar tvog doma."""
        import shutil
        src, dst = self.path(src_rel, follow_last=False), self.path(dst_rel, write=True, follow_last=False)
        if os.path.lexists(dst):
            raise FileExistsError("Already exists: %s" % dst_rel)
        if os.path.isdir(src) and not os.path.islink(src):
            if dst == src or dst.startswith(src + os.sep):
                raise ValueError("Can't copy a folder into itself.")
            shutil.copytree(src, dst)
        else:
            shutil.copyfile(src, dst)

    def move(self, src_rel, dst_rel):
        """Premješta / preimenuje unutar tvog doma."""
        import shutil
        src, dst = self.path(src_rel, write=True, follow_last=False), self.path(dst_rel, write=True, follow_last=False)
        if os.path.lexists(dst):
            raise FileExistsError("Already exists: %s" % dst_rel)
        if os.path.isdir(src) and (dst == src or dst.startswith(src + os.sep)):
            raise ValueError("Can't move a folder into itself.")
        shutil.move(src, dst)

    def remove(self, rel):
        p = self.path(rel, write=True, follow_last=False)
        if p == os.path.realpath(self._stuff("fs.user.write")):
            raise PermissionDenied("Can't delete the home folder itself.")
        fsx.remove(p)

    # ---- zvuk, slike, informacije
    @property
    def audio(self):
        self._need("audio")
        from helpers import audio
        return audio

    def image(self, rel):
        from helpers import imaging
        return imaging.load(self.path(rel))

    def sysinfo(self):
        self._need("sysinfo")
        from helpers import sysinfo
        return sysinfo.collect()

    # ---- aplikacije
    def apps(self):
        self._need("apps.list")
        with guard.privileged():
            return [{"id": a.id, "name": a.name, "version": a.version, "description": a.description,
                     "signature": a.verification.describe(), "permissions": sorted(apps.current_grants(a))}
                    for a in apps.list_installed()]

    def start_app(self, app_id, args=None):
        self._need("apps.launch")
        with guard.privileged():
            return apps.spawn(app_id, self._ctx.user, args)

    def install(self, rel):
        self._need("apps.install")
        if not users.is_admin(self._ctx.user or ""):
            raise PermissionDenied("Only root can install packages.")
        src = self.path(rel)
        with guard.privileged():
            info = apps.inspect(src)
            if not info.signed:
                raise PermissionDenied("Only packages with an official or trusted signature can be installed from an app.")
            return apps.install(src, lambda i, offered: offered)

    # ---- store (paketi koji dolaze s OS-om u /usr/share/store)
    def store_list(self):
        self._need("apps.list")
        with guard.privileged():
            installed = {a.id: a for a in apps.list_installed()}
        out = []
        store = paths.STORE_DIR
        if not os.path.isdir(store):
            return out
        with guard.privileged():
            for fname in sorted(os.listdir(store)):
                if not fname.endswith(cockz.EXT):
                    continue
                try:
                    info = apps.read_manifest(os.path.join(store, fname))
                except apps.AppError:
                    continue
                cur = installed.get(info.id)
                out.append({"id": info.id, "name": info.name, "version": info.version, "description": info.description,
                            "permissions": list(info.permissions), "signature": info.verification.describe(),
                            "signed": info.signed, "installed": cur is not None,
                            "installed_version": cur.version if cur else None})
        return out

    def store_install(self, app_id):
        self._need("apps.install")
        if not users.is_admin(self._ctx.user or ""):
            raise PermissionDenied("Only root can install apps.")
        with guard.privileged():
            path = os.path.join(paths.STORE_DIR, app_id + cockz.EXT)
            if not os.path.isfile(path) or not apps._ID_RE.fullmatch(app_id):
                raise apps.AppError("Not in the store: %s" % app_id)
            info = apps.inspect(path)
            if not info.signed:
                raise PermissionDenied("Store packages must be signed by an official or trusted key.")
            return apps.install(path, lambda i, offered: offered)

    def uninstall(self, app_id):
        self._need("apps.install")
        if not users.is_admin(self._ctx.user or ""):
            raise PermissionDenied("Only root can remove apps.")
        if app_id == self._ctx.id:
            raise PermissionDenied("An app can't remove itself.")
        with guard.privileged():
            return apps.uninstall(app_id)

    # ---- ključevi i paketi
    def trusted_keys(self):
        with guard.privileged():                       # /etc/trust.d nije za aplikacije, ali ključevi su javni
            return {k: {"name": v["name"], "level": v["level"]} for k, v in trust.trusted_keys().items()}

    def verify(self, rel):
        pkg = cockz.open_package(self.path(rel))
        ver = pkg.verify(self.trusted_keys())
        pkg.verify_all()
        return {"kind": pkg.kind, "status": ver.status, "signer": ver.signer, "key_id": ver.key_id,
                "files": len(pkg.files), "meta": pkg.meta, "describe": ver.describe()}

    def pack(self, folder_rel, out_rel, key_rel=None):
        seed = trust.load_private(self.path(key_rel)) if key_rel else None
        return cockz.pack(self.path(folder_rel), self.path(out_rel, write=True), seed)

    def unpack(self, file_rel, dest_rel, force=False):
        pkg = cockz.open_package(self.path(file_rel))
        ver = pkg.verify(self.trusted_keys())
        if ver.status == cockz.STATUS_BAD:
            raise cockz.CockzError("Signature check FAILED: %s" % ver.describe())
        if not ver.ok and not force:
            raise cockz.CockzError("Package is %s. Use force to unpack anyway." % ver.describe())
        return pkg.extract(self.path(dest_rel, write=True))
