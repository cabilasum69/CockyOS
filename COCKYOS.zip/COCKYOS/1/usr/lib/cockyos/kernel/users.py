"""Korisnici i lozinke.  /home/<ime> (root: /root) je dom; lozinke su u /etc/shadow kao PBKDF2-SHA256 hash.

Unutar doma: obični fajlovi korisnika, ~/.config i ~/.local/share/<app> (podaci aplikacija; druge aplikacije ih ne vide).
"""
import base64
import hashlib
import hmac
import os
import re
import secrets
import shutil

from . import paths

ADMIN_USER = "root"
_NAME_RE = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.-]*")
ITERATIONS = 200000
HIDDEN_DIRS = (".config", ".local")          # aplikacije ih ne smiju dirati osim svoje podmape


def is_admin(username):
    return username == ADMIN_USER


def valid_name(username):
    return bool(_NAME_RE.fullmatch(username or "")) and len(username) <= 32


def user_dir(username):
    return paths.ROOT_HOME if is_admin(username) else os.path.join(paths.HOME_DIR, username)


home_dir = user_dir
stuff_dir = user_dir                         # staro ime, isto značenje


def get_users():
    out = []
    if os.path.isdir(paths.ROOT_HOME):
        out.append(ADMIN_USER)
    if os.path.isdir(paths.HOME_DIR):
        out += sorted(u for u in os.listdir(paths.HOME_DIR)
                      if valid_name(u) and u != ADMIN_USER and os.path.isdir(os.path.join(paths.HOME_DIR, u)))
    return out


def exists(username):
    return valid_name(username) and os.path.isdir(user_dir(username))


def create_user(username, password=""):
    """Stvara korisnika. Vraća (ok, poruka)."""
    if not valid_name(username):
        return False, "Invalid username (use letters, numbers, _ . -, max 32)."
    if os.path.exists(user_dir(username)):
        return False, "User already exists."
    os.makedirs(os.path.join(user_dir(username), ".config"), exist_ok=True)
    os.makedirs(os.path.join(user_dir(username), ".local", "share"), exist_ok=True)
    if password:
        set_password(username, password)
    return True, "User '%s' created." % username


def delete_user(username):
    """Briše korisnika, njegov dom i lozinku. Vraća (ok, poruka)."""
    if is_admin(username):
        return False, "The root account can't be deleted."
    if not exists(username):
        return False, "No such user."
    shutil.rmtree(user_dir(username))
    _write_shadow({u: h for u, h in _read_shadow().items() if u != username})
    return True, "User deleted."


# ---------- /etc/shadow ----------
def _read_shadow():
    out = {}
    try:
        with open(paths.SHADOW_FILE, encoding="utf-8") as f:
            for line in f:
                user, _, h = line.rstrip("\n").partition(":")
                if user and h:
                    out[user] = h
    except OSError:
        pass
    return out


def _write_shadow(entries):
    os.makedirs(paths.ETC_DIR, exist_ok=True)
    tmp = paths.SHADOW_FILE + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        for user in sorted(entries):
            f.write("%s:%s\n" % (user, entries[user]))
    os.replace(tmp, paths.SHADOW_FILE)
    try:
        os.chmod(paths.SHADOW_FILE, 0o600)
    except OSError:
        pass


def hash_password(password, salt=None, iterations=ITERATIONS):
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return "pbkdf2_sha256$%d$%s$%s" % (iterations, base64.b64encode(salt).decode(), base64.b64encode(dk).decode())


def _verify_hash(stored, entered):
    try:
        algo, iters, salt, dk = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        calc = hashlib.pbkdf2_hmac("sha256", entered.encode("utf-8"), base64.b64decode(salt), int(iters))
        return hmac.compare_digest(calc, base64.b64decode(dk))
    except (ValueError, TypeError):
        return False


def has_password(username):
    return username in _read_shadow()


def check_password(username, entered):
    """True ako je lozinka točna (ili korisnik nema lozinku)."""
    stored = _read_shadow().get(username)
    return True if stored is None else _verify_hash(stored, entered)


def set_password(username, password):
    """Prazna lozinka = ukloni lozinku."""
    entries = _read_shadow()
    if password:
        entries[username] = hash_password(password)
    else:
        entries.pop(username, None)
    _write_shadow(entries)
