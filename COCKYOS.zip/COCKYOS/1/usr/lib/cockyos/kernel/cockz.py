"""Kompatibilni naziv: format .cockz živi u biblioteci /usr/lib/cockz (import cockz). Ovdje se samo prosljeđuje."""
import cockz as _lib

globals().update({k: v for k, v in vars(_lib).items() if not k.startswith("__")})
