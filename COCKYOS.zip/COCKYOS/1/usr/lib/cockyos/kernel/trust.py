"""Povjerenje: koji javni ključevi smiju potpisivati pakete. Datoteke u /etc/trust.d/*.pub (logika je u cockz.keys).

    official.pub     službeni ključ CockyOS-a (paketi s njim dobivaju sve dozvole koje traže)
    <ime>.pub        ključ kojem je root povjerovao (trust add)
"""
import cockz
from cockz import keys as _keys
from cockz.keys import TrustError, generate_keypair, load_private, read_pub_file  # noqa: F401

from . import paths

TRUST_DIR = paths.TRUST_DIR


def trusted_keys():
    return _keys.trusted_keys(TRUST_DIR)


def add_key(name, pub_hex):
    return _keys.add_key(TRUST_DIR, name, pub_hex)


def remove_key(name):
    return _keys.remove_key(TRUST_DIR, name)


def verify(path):
    """Otvori paket i provjeri potpis prema povjerenim ključevima. Vraća (Package, Verification)."""
    pkg = cockz.open_package(path)
    return pkg, pkg.verify(trusted_keys())
