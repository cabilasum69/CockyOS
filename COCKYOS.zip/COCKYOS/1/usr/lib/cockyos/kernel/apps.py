"""CockyOS aplikacije.

Aplikacija je .cockz paket (kind "app", potpisan) ili - zbog starih aplikacija - obični ZIP .capp (uvijek "unsigned").

    moja_app.cockz
    ├── app.json     {"id": "moja-app", "name": "Moja App", "version": "1.0", "entry": "main.py",
    │                 "permissions": ["gui", "fs.user.read"], "platforms": ["windows", "linux", "macos"]}
    ├── main.py      def main(ctx): ...
    ├── assets/      slike, kursori, podaci...
    └── scripts/     pomoćni .py ili .cock (Cock67) skripte

Instalirane aplikacije žive u /usr/bin (usr/bin). Pri pokretanju kernel provjeri potpis, raspakira paket u COCKYCACHE
(samo ako se promijenio), izračuna dozvole, uključi guard i tek onda pozove main(ctx) - u zasebnom procesu.
"""
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile

from . import cache, cockz, guard, hal, log, paths, perms, trust, users

EXT = cockz.EXT
LEGACY_EXT = ".capp"
EXTS = (EXT, LEGACY_EXT)
MANIFEST = "app.json"
MAX_UNPACKED = cockz.MAX_UNPACKED
_ID_RE = re.compile(r"[a-z0-9][a-z0-9_-]{0,31}")
PROCESS_ENV = "COCKY_APP_PROCESS"

_log = log.get("CockyOS.apps")


class AppError(Exception):
    pass


class AppInfo(object):
    def __init__(self, app_id, name, version, entry, description, path, platforms, permissions, legacy,
                 verification, digest):
        self.id = app_id
        self.name = name
        self.version = version
        self.entry = entry
        self.description = description
        self.path = path
        self.platforms = platforms        # None = radi na svim OS-ima
        self.permissions = permissions    # što paket traži
        self.legacy = legacy              # True = stari .capp (zip)
        self.verification = verification
        self.digest = digest              # hex otisak paketa

    @property
    def signed(self):
        return self.verification.ok


# ---------- čitanje / provjera paketa ----------
def _safe_member(name):
    return cockz.safe_member(name)


def _parse_manifest(data, names):
    if not isinstance(data, dict):
        raise AppError("%s must contain a JSON object." % MANIFEST)
    app_id = str(data.get("id", ""))
    if not _ID_RE.fullmatch(app_id):
        raise AppError("Invalid app id '%s' (use a-z, 0-9, - and _, max 32 chars)." % app_id)
    entry = str(data.get("entry", "main.py")).replace("\\", "/")
    if entry not in names or not entry.endswith(".py"):
        raise AppError("Entry file '%s' not found in package." % entry)
    platforms = data.get("platforms")
    if platforms is not None:
        if (not isinstance(platforms, list) or not platforms
                or any(p not in hal.SUPPORTED for p in platforms)):
            raise AppError("'platforms' must be a list of: %s." % ", ".join(hal.SUPPORTED))
    declared, bad = perms.normalize(data.get("permissions", []))
    if bad:
        raise AppError("Unknown permission(s): %s." % ", ".join(bad))
    return app_id, entry, platforms, declared


_inspect_cache = {}


def read_manifest(path):
    """Provjeri paket (.cockz ili .capp) i vrati AppInfo (s potpisom i dozvolama). Baca AppError."""
    try:
        st = os.stat(path)
    except OSError:
        raise AppError("File not found: %s" % path)
    key = (os.path.abspath(path), st.st_mtime_ns, st.st_size, sorted(trust.trusted_keys()).__repr__())
    if key in _inspect_cache:
        return _inspect_cache[key]
    if path.lower().endswith(LEGACY_EXT):
        info = _read_legacy(path)
    else:
        info = _read_cockz(path)
    _inspect_cache.clear()
    _inspect_cache[key] = info
    return info


def _read_cockz(path):
    try:
        pkg = cockz.open_package(path)
        if pkg.kind != "app":
            raise AppError("This package is a '%s', not an app." % pkg.kind)
        ver = pkg.verify(trust.trusted_keys())
        digest = pkg.digest().hex()
        app_id, entry, platforms, declared = _parse_manifest(pkg.meta, pkg.names())
    except cockz.CockzError as e:
        raise AppError(str(e))
    meta = pkg.meta
    return AppInfo(app_id, str(meta.get("name", app_id)), str(meta.get("version", "1.0")), entry,
                   str(meta.get("description", "")), path, platforms, declared, False, ver, digest)


def _read_legacy(path):
    import hashlib
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        raise AppError("Not a valid %s file (it must be a zip)." % LEGACY_EXT)
    with z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        bad = [n for n in names if not _safe_member(n)]
        if bad:
            raise AppError("Unsafe path inside package: %s" % bad[0])
        if sum(i.file_size for i in infos) > MAX_UNPACKED:
            raise AppError("Package is too big when unpacked.")
        if MANIFEST not in names:
            raise AppError("Missing %s in package." % MANIFEST)
        try:
            data = json.loads(z.read(MANIFEST).decode("utf-8"))
        except ValueError:
            raise AppError("%s is not valid JSON." % MANIFEST)
    app_id, entry, platforms, declared = _parse_manifest(data, names)
    with open(path, "rb") as f:
        digest = hashlib.sha256(f.read()).hexdigest()
    return AppInfo(app_id, str(data.get("name", app_id)), str(data.get("version", "1.0")), entry,
                   str(data.get("description", "")), path, platforms, declared, True,
                   cockz.Verification(cockz.STATUS_UNSIGNED), digest)


def installed_path(app_id):
    for ext in EXTS:
        p = os.path.join(paths.APPS_DIR, app_id + ext)
        if os.path.isfile(p):
            return p
    return os.path.join(paths.APPS_DIR, app_id + EXT)


def list_installed():
    found, seen = [], set()
    if not os.path.isdir(paths.APPS_DIR):
        return found
    for fname in sorted(os.listdir(paths.APPS_DIR)):
        if not fname.lower().endswith(EXTS):
            continue
        try:
            info = read_manifest(os.path.join(paths.APPS_DIR, fname))
        except AppError as e:
            _log.warning("Skipping broken app %s: %s", fname, e)
            continue
        if info.id not in seen:
            seen.add(info.id)
            found.append(info)
    return found


def find(app_id):
    app_id = (app_id or "").lower()
    for ext in EXTS:
        if app_id.endswith(ext):
            app_id = app_id[:-len(ext)]
    if not _ID_RE.fullmatch(app_id):
        raise AppError("Invalid app name '%s'." % app_id)
    path = installed_path(app_id)
    if not os.path.isfile(path):
        raise AppError("App '%s' is not installed (type 'apps' to see what is)." % app_id)
    return read_manifest(path)


# ---------- instalacija ----------
def inspect(src_path):
    """Za install: AppInfo bez da se išta kopira."""
    info = read_manifest(src_path)
    if not info.legacy:
        try:
            cockz.open_package(src_path).verify_all()
        except cockz.CockzError as e:
            raise AppError(str(e))
    if info.verification.status == cockz.STATUS_BAD:
        raise AppError("Signature check FAILED: %s. Refusing to install." % info.verification.describe())
    return info


def install(src_path, choose_perms, allow_unsigned=False):
    """Instalira paket. choose_perms(info, ponudene_dozvole) -> lista odobrenih (ili None = odustani).
    Vraća (AppInfo, zamijenjena_stara_verzija, odobrene_dozvole)."""
    info = inspect(src_path)
    if not info.signed and not allow_unsigned:
        raise AppError("Package is %s. Only signed packages (official or trusted key) can be installed; "
                       "root can override explicitly." % info.verification.describe())
    offered = perms.proposable(info.permissions, info.verification)
    if info.verification.status == cockz.STATUS_OFFICIAL:
        chosen = list(offered)
    else:
        chosen = choose_perms(info, offered)
        if chosen is None:
            raise AppError("Installation cancelled.")
        chosen = [p for p in chosen if p in offered]
    dst = os.path.join(paths.APPS_DIR, info.id + (LEGACY_EXT if info.legacy else EXT))
    replaced = os.path.exists(installed_path(info.id))
    os.makedirs(paths.APPS_DIR, exist_ok=True)
    if os.path.abspath(src_path) != os.path.abspath(dst):
        tmp = dst + ".part"
        shutil.copyfile(src_path, tmp)
        os.replace(tmp, dst)
        other = os.path.join(paths.APPS_DIR, info.id + (EXT if info.legacy else LEGACY_EXT))
        if os.path.isfile(other):
            os.remove(other)
    perms.grant(info.id, info.digest, chosen)
    _log.info("Installed app '%s' v%s [%s] perms=%s%s", info.id, info.version, info.verification.describe(),
              ",".join(chosen) or "-", " (replaced)" if replaced else "")
    return info, replaced, chosen


def uninstall(app_id):
    info = find(app_id)
    os.remove(info.path)
    perms.revoke(info.id)
    shutil.rmtree(cache.app_dir(info.id), ignore_errors=True)
    _log.info("Uninstalled app '%s'", info.id)
    return info


def current_grants(info):
    """Dozvole koje će aplikacija stvarno dobiti pri pokretanju."""
    return perms.effective(info.id, info.permissions, info.verification, info.digest)


# ---------- raspakiravanje u COCKYCACHE ----------
def unpack(info):
    """Raspakira aplikaciju u cache (preskače ako je već svježe). Vraća folder."""
    cache.ensure()
    dest = cache.app_dir(info.id)
    stamp = info.digest
    stamp_file = os.path.join(dest, ".stamp")
    if os.path.isfile(stamp_file) and os.path.isfile(os.path.join(dest, info.entry)):
        with open(stamp_file) as f:
            if f.read().strip() == stamp:
                return dest

    shutil.rmtree(dest, ignore_errors=True)
    tmp = dest + ".part"
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    try:
        if info.legacy:
            real_tmp = os.path.realpath(tmp)
            with zipfile.ZipFile(info.path) as z:
                for member in z.infolist():
                    target = os.path.realpath(os.path.join(tmp, member.filename))
                    if os.path.commonpath([real_tmp, target]) != real_tmp:
                        raise AppError("Unsafe path inside package: %s" % member.filename)
                    z.extract(member, tmp)
        else:
            cockz.open_package(info.path).extract(tmp)
    except (cockz.CockzError, AppError) as e:
        shutil.rmtree(tmp, ignore_errors=True)
        raise AppError(str(e))
    with open(os.path.join(tmp, ".stamp"), "w") as f:
        f.write(stamp)
    os.rename(tmp, dest)
    _log.info("Unpacked '%s' into %s", info.id, dest)
    return dest


# ---------- pokretanje ----------
class AppContext(object):
    """Ovo aplikacija dobije kao argument main(ctx)."""

    def __init__(self, info, app_dir, user, args, granted):
        from . import api as _api
        self.id = info.id
        self.name = info.name
        self.version = info.version
        self.user = user
        self.args = list(args or [])
        self.dir = app_dir
        self.assets_dir = os.path.join(app_dir, "assets")
        self.scripts_dir = os.path.join(app_dir, "scripts")
        self.platform = hal.NAME                  # "windows" / "linux" / "macos"
        self.log = log.get("CockyOS.app." + info.id)
        self.permissions = frozenset(granted)
        self.signature = info.verification.describe()
        self.kernel = _api.KernelView(self)       # ograničen pogled na kernel
        self.api = _api.Api(self)                 # pozivi kernela koji traže dozvole

    def has(self, perm):
        return perm in self.permissions

    @property
    def data_dir(self):
        """Trajni podaci aplikacije za tog korisnika (NE u cacheu, cache se smije brisati)."""
        d = data_dir_for(self.id, self.user)
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        return d

    def _inside(self, base, name):
        full = os.path.realpath(os.path.join(base, name))
        if os.path.commonpath([os.path.realpath(base), full]) != os.path.realpath(base):
            raise AppError("Path escapes the app folder: %s" % name)
        return full

    def asset(self, name):
        """Puna putanja do datoteke iz assets/."""
        return self._inside(self.assets_dir, name)

    def script(self, name):
        """Puna putanja do datoteke iz scripts/."""
        return self._inside(self.scripts_dir, name)

    def run_cock67(self, name):
        """Pokreće Cock67 skriptu iz scripts/."""
        from . import cock67
        cock67.execute_script(self.script(name))


def data_dir_for(app_id, user):
    """Trajni podaci aplikacije za korisnika: ~/.local/share/<app> (ne u cacheu, cache se smije brisati)."""
    if user and users.exists(user):
        return os.path.join(users.user_dir(user), ".local", "share", app_id)
    return os.path.join(cache.tmp_dir(), app_id)


def _purge_modules(app_dir, before):
    """Makni module koje je aplikacija učitala, da se ne miješaju s drugim aplikacijama."""
    base = os.path.realpath(app_dir)
    for name in list(sys.modules):
        if name in before:
            continue
        mod = sys.modules[name]
        locations = [getattr(mod, "__file__", None)]
        try:
            locations += list(getattr(mod, "__path__", []))
        except TypeError:
            pass
        if any(loc and os.path.realpath(loc).startswith(base) for loc in locations):
            del sys.modules[name]


def _guard_roots(info, app_dir, user, granted):
    from helpers import libs as _libs
    data = data_dir_for(info.id, user)
    tmp = os.path.join(cache.tmp_dir(), info.id)
    os.makedirs(data, exist_ok=True)
    os.makedirs(tmp, exist_ok=True)
    home = users.user_dir(user) if user and users.exists(user) else None
    hidden = []
    if home:
        os.makedirs(home, exist_ok=True)
        hidden = [os.path.join(home, h) for h in users.HIDDEN_DIRS]
    read = [app_dir, paths.SYSTEM_DIR, paths.LIB_DIR, _libs.cache_root(), paths.RUNTIME_ROOT, data, tmp] \
        + guard.system_read_roots()
    deny = []
    if "fs.system.read" in granted:
        read.append(paths.PARTITION)
        deny += [paths.HOME_DIR, paths.ROOT_HOME]
    return read, [data, tmp], home, deny, hidden


def launch(app_id, user=None, args=None):
    """Pokreće aplikaciju U OVOM procesu (samo iz runapp.py) uz guard. Vraća povratnu vrijednost main(ctx)."""
    if not os.environ.get(PROCESS_ENV):
        raise AppError("Apps run in their own process: use apps.run() or apps.spawn().")
    info = find(app_id)
    if info.verification.status == cockz.STATUS_BAD:
        raise AppError("Refusing to run '%s': %s" % (info.id, info.verification.describe()))
    if info.platforms and hal.NAME not in info.platforms:
        raise AppError("App '%s' does not support %s (it supports: %s)." % (info.id, hal.NAME, ", ".join(info.platforms)))
    granted = current_grants(info)
    app_dir = unpack(info)
    ctx = AppContext(info, app_dir, user, args, granted)

    modname = "cockapp_" + info.id.replace("-", "_")
    spec = importlib.util.spec_from_file_location(modname, os.path.join(app_dir, info.entry))
    module = importlib.util.module_from_spec(spec)
    sys.path.insert(0, app_dir)
    read, write, stuff, deny, hidden = _guard_roots(info, app_dir, user, granted)
    _log.info("Launching '%s' for user '%s' [%s] perms=%s", info.id, user, info.verification.describe(),
              ",".join(sorted(granted)) or "-")
    guard.install(info.id, granted, read, write, stuff, deny_roots=deny, hidden_roots=hidden,
                  kernel_dirs=[paths.KERNEL_DIR, paths.HELPERS_DIR, paths.COCKZ_LIB_DIR])
    before = set(sys.modules)
    try:
        spec.loader.exec_module(module)
        main = getattr(module, "main", None)
        if not callable(main):
            raise AppError("%s has no main(ctx) function." % info.entry)
        return main(ctx)
    except SystemExit as e:                  # app je pozvala exit(); to ne smije ugasiti OS
        _log.info("App '%s' exited (%s)", info.id, e.code)
        return e.code
    except KeyboardInterrupt:
        _log.info("App '%s' interrupted", info.id)
        raise
    except Exception:
        _log.exception("App '%s' crashed", info.id)
        raise
    finally:
        _purge_modules(app_dir, before)


def _command(info, user, args):
    return [sys.executable, os.path.join(paths.SYSTEM_DIR, "runapp.py"), info.id, user or ""] + list(args or [])


def _env():
    return dict(os.environ, COCKYCACHE=paths.CACHE_DIR, **{PROCESS_ENV: "1"})


# procesi pokrenuti iz OVE sesije (za ps / kill): pid -> {"proc", "app", "user", "started", "background"}
PROCESSES = {}


def _register(proc, info, user, background):
    PROCESSES[proc.pid] = {"proc": proc, "app": info.id, "user": user, "started": time.time(), "background": background}
    for pid in [p for p, v in PROCESSES.items() if v["proc"].poll() is not None and p != proc.pid]:
        if time.time() - PROCESSES[pid]["started"] > 3600:
            del PROCESSES[pid]


def running():
    """[(pid, app, user, started, background)] za procese koji još rade."""
    return [(pid, v["app"], v["user"], v["started"], v["background"]) for pid, v in sorted(PROCESSES.items())
            if v["proc"].poll() is None]


def kill(pid):
    """Gasi aplikaciju koju je pokrenula ova sesija. Vraća True ako je postojala."""
    v = PROCESSES.get(pid)
    if not v or v["proc"].poll() is not None:
        return False
    v["proc"].terminate()
    try:
        v["proc"].wait(3)
    except subprocess.TimeoutExpired:
        v["proc"].kill()
    return True


def run(app_id, user=None, args=None):
    """Pokreće aplikaciju u zasebnom procesu i čeka da završi. Vraća exit code."""
    info = find(app_id)
    _log.info("Running '%s' for user '%s'", info.id, user)
    proc = subprocess.Popen(_command(info, user, args), cwd=paths.PARTITION, env=_env())
    _register(proc, info, user, False)
    try:
        return proc.wait()
    except KeyboardInterrupt:
        try:
            return proc.wait(3)
        except subprocess.TimeoutExpired:
            proc.terminate()
            raise


def spawn(app_id, user=None, args=None):
    """Pokreće aplikaciju u zasebnom procesu u pozadini (za GUI aplikacije). Vraća Popen."""
    info = find(app_id)
    _log.info("Spawning '%s' for user '%s'", info.id, user)
    proc = subprocess.Popen(_command(info, user, args), cwd=paths.PARTITION, env=_env())
    _register(proc, info, user, True)
    return proc
