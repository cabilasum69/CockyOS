"""Dozvole aplikacija. Aplikacija u app.json navodi što treba:  "permissions": ["gui", "fs.user.read"]

Što je dopušteno na kraju određuje root pri instalaciji (a službeno potpisani paketi dobivaju sve što traže).
Odobrene dozvole pamte se u /etc/perms.json zajedno s otiskom paketa; ako se paket promijeni,
odobrenje više ne vrijedi i mora se ponovno dati.  Dozvole provodi kernel.guard u procesu aplikacije.
"""
import json
import os

from . import cockz, paths

CATALOG = {
    "gui":            ("Open windows (Tk)", "low"),
    "audio":          ("Play sound", "low"),
    "sysinfo":        ("Read OS / hardware information", "low"),
    "apps.list":      ("See which apps are installed", "low"),
    "apps.launch":    ("Start other apps", "medium"),
    "fs.user.read":   ("Read files in your home folder (~)", "medium"),
    "fs.user.write":  ("Create, change and delete files in your home folder (~)", "medium"),
    "fs.system.read": ("Read CockyOS system files (never passwords)", "high"),
    "net":            ("Use the network", "high"),
    "proc.spawn":     ("Start other programs on this computer", "high"),
    "native":         ("Use native code (ctypes) - bypasses most protection", "high"),
    "apps.install":   ("Install / remove packages (works only for root)", "high"),
}
DANGEROUS = frozenset(k for k, v in CATALOG.items() if v[1] == "high")
GRANTS_FILE = paths.GRANTS_FILE


def normalize(declared):
    """Očisti popis iz app.json: samo poznate dozvole, bez duplikata. Vraća (popis, nepoznate)."""
    if not isinstance(declared, list):
        return [], []
    good, bad = [], []
    for p in declared:
        if isinstance(p, str) and p in CATALOG:
            if p not in good:
                good.append(p)
        else:
            bad.append(str(p))
    return good, bad


def _load():
    try:
        with open(GRANTS_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(d):
    tmp = GRANTS_FILE + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2, sort_keys=True)
    os.replace(tmp, GRANTS_FILE)


def proposable(declared, verification):
    """Što se smije ponuditi rootu pri instalaciji. Nepotpisani i nepoznati paketi ne mogu tražiti 'high'."""
    declared, _ = normalize(declared)
    if verification.status in (cockz.STATUS_OFFICIAL, cockz.STATUS_TRUSTED):
        return declared
    return [p for p in declared if p not in DANGEROUS]


def grant(app_id, package_digest_hex, perms):
    d = _load()
    d[app_id] = {"digest": package_digest_hex, "granted": sorted(set(perms))}
    _save(d)


def revoke(app_id):
    d = _load()
    if d.pop(app_id, None) is not None:
        _save(d)


def granted(app_id, package_digest_hex):
    rec = _load().get(app_id)
    if not rec or rec.get("digest") != package_digest_hex:
        return None
    return [p for p in rec.get("granted", []) if p in CATALOG]


def effective(app_id, declared, verification, package_digest_hex):
    """Skup dozvola koje aplikacija stvarno ima pri pokretanju."""
    declared, _ = normalize(declared)
    if verification.status == cockz.STATUS_BAD:
        return set()
    if verification.status == cockz.STATUS_OFFICIAL:
        return set(declared)                                  # službeni paket: sve što traži
    rec = granted(app_id, package_digest_hex)
    if rec is None:
        return set()                                          # nikad odobreno (ili se paket promijenio)
    allowed = set(declared) & set(rec)
    if verification.status not in (cockz.STATUS_TRUSTED,):
        allowed -= DANGEROUS
    return allowed


def describe(perm):
    d, risk = CATALOG.get(perm, ("(unknown)", "high"))
    return "%-15s %-7s %s" % (perm, risk.upper(), d)
