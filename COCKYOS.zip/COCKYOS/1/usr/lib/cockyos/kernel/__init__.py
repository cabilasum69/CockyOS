"""CockyOS kernel - sve što sistemski programi i aplikacije smiju koristiti.

    import kernel
    kernel.boot()                       # jednom, na početku (system.py to radi)
    kernel.hal / users / apps / cache / console / paths / log / vfs / cockz / trust / perms / guard / api
"""
import os
import platform
import sys

_SYSTEM = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))     # /usr/lib/cockyos  (kernel, helpers, sys)
_LIB = os.path.dirname(_SYSTEM)                                           # /usr/lib          (cockz)
for _p in (_LIB, _SYSTEM):
    if _p not in sys.path:
        sys.path.insert(0, _p)

VERSION = "3.1"

from . import hal, paths, log, console, users, cache, vfs, ed25519, cockz, trust, perms, guard, apps, api  # noqa: E402


def boot(verbose=False, banner=True):
    """Priprema OS: mape, logiranje, COCKYCACHE. Sigurno je zvati više puta."""
    paths.ensure()
    log.setup(verbose)
    cache.ensure()
    from helpers import libs                    # potpisani libovi (npr. Pillow) iz libs/*.cockz -> sys.path
    libs.activate_all()
    if banner:
        k = log.get("CockyOS.kernel")
        k.info("=" * 60)
        k.info("CockyOS kernel %s starting", VERSION)
        k.info("Python: %s", sys.version.replace("\n", " "))
        k.info("Platform: %s", platform.platform())
        k.info("HAL: %s (runtime id %s)", hal.NAME, hal.RUNTIME_ID)
        k.info("Partition: %s", paths.PARTITION)
        k.info("Homes: %s", paths.HOME_DIR)
        k.info("Trusted keys: %s", ", ".join(v["name"] for v in trust.trusted_keys().values()) or "(none)")
        k.info("Apps: %s", paths.APPS_DIR)
        k.info("COCKYCACHE: %s", paths.CACHE_DIR)
        k.info("Log file: %s", log.LOG_FILE)
