"""Terminal helperi - OS-neovisni; sve OS-specifično je u kernel.hal."""
import os
import shutil
import sys

from . import hal
from .hal import clear, cbreak, kbhit, getch  # noqa: F401  (ostali moduli ih uzimaju odavde)


def term_size():
    try:
        size = os.get_terminal_size()
        return size.columns, size.lines
    except OSError:
        size = shutil.get_terminal_size((80, 25))
        return size.columns, size.lines


def center(text, width=None):
    width = width or term_size()[0]
    return text.center(width)


def indent_for(width):
    """Razmak slijeva da blok zadane širine bude na sredini."""
    return max((term_size()[0] - width) // 2, 0)


def cprint(text=""):
    print(center(text))


def cinput(prompt, field=20):
    """Prompt je centriran u svom redu, a polje za unos je centrirano ispod."""
    cprint(prompt)
    return input(" " * indent_for(field)).strip()


def read_password(prompt="Password:", field=20):
    """Unos lozinke sa zvjezdicama, centrirano ispod prompta."""
    cprint(prompt)
    sys.stdout.write(" " * indent_for(field))
    sys.stdout.flush()
    chars = []
    with cbreak():
        while True:
            ch = getch()
            if ch in ("\r", "\n"):
                print()
                return "".join(chars)
            elif ch == "\x03":
                raise KeyboardInterrupt
            elif ch in ("\b", "\x7f"):
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
            elif ch and ch.isprintable():
                chars.append(ch)
                sys.stdout.write("*")
                sys.stdout.flush()
