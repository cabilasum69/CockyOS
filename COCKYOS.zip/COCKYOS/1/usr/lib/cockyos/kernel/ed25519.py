"""Kompatibilni naziv: Ed25519 živi u biblioteci /usr/lib/cockz (cockz.ed25519)."""
from cockz.ed25519 import *          # noqa: F401,F403
from cockz.ed25519 import generate, public_key, sign, verify  # noqa: F401
