import sys
import os

def execute_script(file_path):
    print(f"[Cock67 Engine] Pokretanje skripte: {file_path}")
    if not os.path.exists(file_path):
        print(f"[Cock67 Error] Datoteka '{file_path}' nije pronađena.")
        return

    variables = {}
    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    for line_no, line in enumerate(lines, 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue # Preskoči prazne linije i komentare

        try:
            # Naredba za ispis teksta (podržava i varijable poput $ime)
            if line.startswith("say "):
                text = line[4:].strip()
                for var_name, var_val in variables.items():
                    text = text.replace(f"${var_name}", str(var_val))
                print(text)

            # Naredba za definiranje varijable: set ime = "Vrijednost"
            elif line.startswith("set "):
                parts = line[4:].split("=", 1)
                if len(parts) == 2:
                    var_name = parts[0].strip()
                    var_val = parts[1].strip().strip('"\'')
                    variables[var_name] = var_val

            # Naredba za unos s tipkovnice: input var_name -> "Unesi nešto:"
            elif line.startswith("input "):
                parts = line[6:].split("->", 1)
                if len(parts) == 2:
                    var_name = parts[0].strip()
                    prompt_msg = parts[1].strip().strip('"\'')
                    val = input(prompt_msg + " ")
                    variables[var_name] = val

            # Naredba za izvršavanje sistemskih komandi
            elif line.startswith("exec "):
                cmd = line[5:].strip()
                os.system(cmd)

            else:
                print(f"[Cock67 Warning] Nepoznata naredba u liniji {line_no}: {line}")
        except Exception as e:
            print(f"[Cock67 Runtime Error] Greška u liniji {line_no}: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        execute_script(sys.argv[1])
    else:
        print("Cock67 Language Interpreter v1.0")
        print("Upotreba: py cock67.py <skripta.cock>")