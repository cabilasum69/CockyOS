"""COCKYCACHE - zasebna 'particija' za privremene stvari (raspakirane aplikacije, tmp).

Sve unutra se može obrisati u svakom trenutku; kernel ga ponovno napravi po potrebi.
Brisanje radi SAMO ako u folderu postoji marker datoteka, da se nikad ne obriše
neki tuđi folder ako je COCKYCACHE env varijabla krivo postavljena.
"""
import os
import shutil

from . import paths

MARKER = ".cockycache"


class CacheError(Exception):
    pass


def ensure():
    d = paths.CACHE_DIR
    marker = os.path.join(d, MARKER)
    if os.path.isdir(d) and not os.path.exists(marker) and os.listdir(d):
        raise CacheError("'%s' is not empty and is not a COCKYCACHE folder." % d)
    os.makedirs(d, exist_ok=True)
    if not os.path.exists(marker):
        with open(marker, "w") as f:
            f.write("COCKYCACHE - safe to delete everything in here except this file.\n")
    os.makedirs(os.path.join(d, "apps"), exist_ok=True)
    os.makedirs(tmp_dir(), exist_ok=True)


def app_dir(app_id):
    """Gdje je raspakirana aplikacija (po particiji, jer dvije particije mogu imati različite verzije)."""
    return os.path.join(paths.CACHE_DIR, "apps", paths.PARTITION_NAME, app_id)


def tmp_dir():
    return os.path.join(paths.CACHE_DIR, "tmp")


def _size(path):
    files = total = 0
    for base, _dirs, names in os.walk(path):
        for n in names:
            files += 1
            try:
                total += os.path.getsize(os.path.join(base, n))
            except OSError:
                pass
    return files, total


def status():
    """Vraća dict: path, files, bytes, apps (popis raspakiranih aplikacija)."""
    ensure()
    files, total = _size(paths.CACHE_DIR)
    root = os.path.join(paths.CACHE_DIR, "apps", paths.PARTITION_NAME)
    apps = sorted(os.listdir(root)) if os.path.isdir(root) else []
    return {"path": paths.CACHE_DIR, "files": files - 1, "bytes": total, "apps": apps}  # -1 = marker


def clear():
    """Briše sve u cacheu (osim markera). Vraća (broj_datoteka, bajtova)."""
    ensure()
    files, total = _size(paths.CACHE_DIR)
    for name in os.listdir(paths.CACHE_DIR):
        if name == MARKER:
            continue
        full = os.path.join(paths.CACHE_DIR, name)
        if os.path.isdir(full):
            shutil.rmtree(full, ignore_errors=True)
        else:
            os.remove(full)
    ensure()
    return files - 1, total
