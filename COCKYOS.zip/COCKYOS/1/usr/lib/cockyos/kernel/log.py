"""Logiranje za cijeli OS. Jedan log file po danu u /var/log/."""
import logging
import os
import sys
import time

from . import paths

LOG_FILE = None
_console_handler = None
_ready = False


def get(name="CockyOS"):
    return logging.getLogger(name)


def _uncaught(exc_type, exc_value, exc_tb):
    """Svaki neuhvaćeni Python error ide u log."""
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return
    get("CockyOS.kernel").critical("Uncaught exception", exc_info=(exc_type, exc_value, exc_tb))
    sys.__excepthook__(exc_type, exc_value, exc_tb)


def setup(verbose=False):
    """Spaja logging na file (idempotentno). verbose=True još ispisuje i na ekran."""
    global LOG_FILE, _console_handler, _ready
    if not _ready:
        LOG_FILE = os.path.join(paths.LOGS_DIR, time.strftime("system_%Y-%m-%d.log"))
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s | %(levelname)-8s | %(name)s | %(funcName)s:%(lineno)d | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8")],
        )
        sys.excepthook = _uncaught
        _ready = True
    if verbose and _console_handler is None:
        _console_handler = logging.StreamHandler(sys.stdout)
        _console_handler.setLevel(logging.INFO)
        _console_handler.setFormatter(logging.Formatter("[ kernel ] %(message)s"))
        logging.getLogger().addHandler(_console_handler)


def quiet():
    """Gasi ispis na ekran (poziva se prije lock screena)."""
    global _console_handler
    if _console_handler is not None:
        logging.getLogger().removeHandler(_console_handler)
        _console_handler = None
