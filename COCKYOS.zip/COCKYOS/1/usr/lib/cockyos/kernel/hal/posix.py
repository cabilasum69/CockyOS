"""Linux / macOS sloj: sve što koristi termios / select."""
import codecs
import contextlib
import os
import select
import sys
import termios
import tty


def clear():
    os.system("clear")


@contextlib.contextmanager
def cbreak():
    """Unutar bloka kbhit()/getch() reagiraju odmah (bez Entera)."""
    if not sys.stdin.isatty():
        yield
        return
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        yield
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def kbhit():
    return bool(select.select([sys.stdin.fileno()], [], [], 0)[0])


_decoder = None


def getch():
    """Jedan znak (unicode); escape sekvence (strelice...) vraćaju ''. Zovi unutar cbreak()."""
    global _decoder
    if _decoder is None:
        _decoder = codecs.getincrementaldecoder("utf-8")("ignore")
    fd = sys.stdin.fileno()
    while True:
        data = os.read(fd, 1)
        if not data:
            raise EOFError
        ch = _decoder.decode(data)
        if ch:
            break
    if ch == "\x1b":
        while kbhit():
            os.read(fd, 1)
        return ""
    return ch
