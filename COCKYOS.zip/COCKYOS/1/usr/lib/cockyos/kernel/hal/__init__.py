"""HAL - sloj između kernela i operacijskog sustava na kojem Python radi.

Ostatak CockyOS-a ne smije znati je li ispod Windows, Linux ili macOS: sve što se razlikuje
(terminal, tipke, runtime) živi ovdje.  Novi OS = nova datoteka u hal/ s istim funkcijama.
"""
import os
import platform
import sys

if sys.platform.startswith("win"):
    NAME = "windows"
    from .windows import clear, cbreak, kbhit, getch
elif sys.platform == "darwin":
    NAME = "macos"
    from .posix import clear, cbreak, kbhit, getch
else:
    NAME = "linux" if sys.platform.startswith("linux") else "unix"
    from .posix import clear, cbreak, kbhit, getch

_ARCHES = {"amd64": "x64", "x86_64": "x64", "x64": "x64", "arm64": "arm64", "aarch64": "arm64",
           "i386": "x86", "i686": "x86", "x86": "x86"}
_machine = (platform.machine() or "").lower()
ARCH = _ARCHES.get(_machine, _machine or "unknown")

#: npr. "windows-x64", "linux-x64", "macos-arm64" - ime mape u runtime/
RUNTIME_ID = NAME + "-" + ARCH

SUPPORTED = ("windows", "linux", "macos")


def runtime_dir(loader_root):
    """Mapa s Pythonom koji je CockyOS donio za ovaj OS (ili None ako koristimo sistemski Python)."""
    d = os.path.join(loader_root, "runtime", RUNTIME_ID)
    return d if os.path.isdir(d) else None


def describe():
    return {
        "os": NAME, "arch": ARCH, "runtime_id": RUNTIME_ID,
        "platform": platform.platform(), "python": platform.python_version(),
        "python_impl": platform.python_implementation(), "executable": sys.executable,
        "bundled_runtime": (os.sep + "runtime" + os.sep + RUNTIME_ID) in os.path.abspath(sys.executable),
    }
