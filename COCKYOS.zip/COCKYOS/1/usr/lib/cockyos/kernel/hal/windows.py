"""Windows sloj: sve što koristi msvcrt / cls."""
import contextlib
import msvcrt
import os


def clear():
    os.system("cls")


@contextlib.contextmanager
def cbreak():
    yield                      # na Windowsu tipke i inače rade odmah


def kbhit():
    return msvcrt.kbhit()


def getch():
    """Jedan znak; posebne tipke (strelice, F1...) vraćaju ''."""
    ch = msvcrt.getwch()
    if ch in ("\x00", "\xe0"):
        msvcrt.getwch()
        return ""
    return ch
