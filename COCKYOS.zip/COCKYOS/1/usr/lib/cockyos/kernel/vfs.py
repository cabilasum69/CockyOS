"""Virtualni simbolički linkovi (rade na Windowsu bez administratora, za razliku od pravih symlinkova).

Link je mala obična datoteka:   b"COCKYLNK1\\n" + cilj (UTF-8, do 1024 B).
  - cilj koji počinje s '/' je apsolutan UNUTAR korijena kaveza (root: cijela particija, korisnik: njegov dom)
  - ostali ciljevi su relativni na mapu u kojoj je link
Razrješavanje prati linkove po cijeloj putanji (do MAX_DEPTH, petlje se odbijaju) i NIKAD ne izlazi iz kaveza.
Pravi OS symlinkovi se također prate, ali moraju završiti unutar kaveza.
"""
import os

MAGIC = b"COCKYLNK1\n"
MAX_TARGET = 1024
MAX_DEPTH = 16


class LinkError(OSError):
    pass


def _norm_rel(rel):
    return [p for p in (rel or "").replace("\\", "/").split("/") if p not in ("", ".")]


def read_link(path):
    """Cilj linka ili None ako to nije link."""
    try:
        if os.path.islink(path):
            return os.readlink(path)
        if not os.path.isfile(path) or os.path.getsize(path) > len(MAGIC) + MAX_TARGET:
            return None
        with open(path, "rb") as f:
            data = f.read(len(MAGIC) + MAX_TARGET + 1)
    except OSError:
        return None
    if not data.startswith(MAGIC):
        return None
    try:
        target = data[len(MAGIC):].decode("utf-8").strip()
    except UnicodeDecodeError:
        return None
    return target or None


def is_link(path):
    return read_link(path) is not None


def symlink(target, link_path):
    """Pravi link na 'target'. Odbija ako link_path već postoji."""
    if not target or len(target.encode("utf-8")) > MAX_TARGET or "\n" in target or "\x00" in target:
        raise LinkError("Invalid link target.")
    if os.path.lexists(link_path):
        raise FileExistsError("Already exists: %s" % os.path.basename(link_path))
    with open(link_path, "wb") as f:
        f.write(MAGIC + target.encode("utf-8") + b"\n")


def resolve(jail, rel, follow_last=True):
    """Razriješi 'rel' (relativno na korijen kaveza 'jail') u pravu OS putanju, prateći linkove.
    Baca PermissionError ako bi izašao iz kaveza, LinkError za petlje."""
    jail = os.path.realpath(jail)
    cur = jail
    queue = _norm_rel(rel)
    hops = 0
    while queue:
        comp = queue.pop(0)
        if comp == "..":
            if cur != jail:
                cur = os.path.dirname(cur)
            continue
        cand = os.path.join(cur, comp)
        target = read_link(cand) if (follow_last or queue) else None
        if target is not None:
            hops += 1
            if hops > MAX_DEPTH:
                raise LinkError("Too many levels of links (loop?).")
            norm = target.replace("\\", "/")
            if norm.startswith("/"):
                cur = jail
            queue = _norm_rel(norm) + queue
            continue
        cur = cand
    real = os.path.realpath(cur) if (follow_last or os.path.isdir(cur)) else os.path.join(
        os.path.realpath(os.path.dirname(cur)), os.path.basename(cur))
    try:
        inside = os.path.commonpath([jail, real]) == jail
    except ValueError:
        inside = False
    if not inside:
        raise PermissionError("Access denied: path leaves the allowed folder.")
    return real


def describe(path, jail=None):
    """Za 'ls -l': (je_link, cilj) - cilj u izvornom obliku."""
    t = read_link(path)
    return (t is not None), t
