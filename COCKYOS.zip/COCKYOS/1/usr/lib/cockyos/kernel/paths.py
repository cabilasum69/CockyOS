"""Sve putanje CockyOS-a na jednom mjestu (Linux-stil / FHS). Nitko drugi ne računa putanje sam.

    /                       (COCKYOS/<n>)  korijen particije
    /boot                   CockBoot.py, config.prop
    /etc                    konfiguracija: trust.d/ (javni ključevi), shadow (lozinke), perms.json (dozvole)
    /usr/bin                instalirane aplikacije (*.cockz)
    /usr/lib/cockyos        kernel/, helpers/, sys/, runapp.py
    /usr/lib/cockz          biblioteka za .cockz (+ unpack.py)
    /usr/lib/modules        libovi / kernel ekstenzije (*.cockz, npr. pillow)
    /usr/share/store        paketi dostupni u cockStore-u
    /var/log  /var/lib/cockyos  /var/run     logovi, stanje, pid-ovi pokrenutih aplikacija
    /home/<user>  /root     korisnički direktoriji (~ ; konfiguracija u ~/.config, podaci u ~/.local/share/<app>)
    /tmp  /opt  /mnt
    /bin -> usr/bin   /lib -> usr/lib    (linkovi, vidi kernel.vfs)
"""
import os

KERNEL_DIR = os.path.dirname(os.path.abspath(__file__))     # .../usr/lib/cockyos/kernel
SYSTEM_DIR = os.path.dirname(KERNEL_DIR)                    # .../usr/lib/cockyos
LIB_DIR = os.path.dirname(SYSTEM_DIR)                       # .../usr/lib
USR_DIR = os.path.dirname(LIB_DIR)                          # .../usr
PARTITION = os.path.dirname(USR_DIR)                        # .../COCKYOS/<n>   = "/"
PARTITION_NAME = os.path.basename(PARTITION)
ROOT = PARTITION

# mapa u kojoj je CockLoader (COCKYOS/ i COCKYCACHE/ i runtime/ su pored njega)
_parent = os.path.dirname(PARTITION)
LOADER_ROOT = os.path.dirname(_parent) if os.path.basename(_parent).upper() == "COCKYOS" else PARTITION
RUNTIME_ROOT = os.path.join(LOADER_ROOT, "runtime")         # runtime/<os>-<arch>/  (Python po OS-u)

BOOT_DIR = os.path.join(PARTITION, "boot")
ETC_DIR = os.path.join(PARTITION, "etc")
TRUST_DIR = os.path.join(ETC_DIR, "trust.d")
SHADOW_FILE = os.path.join(ETC_DIR, "shadow")
GRANTS_FILE = os.path.join(ETC_DIR, "perms.json")
SYS_DIR = os.path.join(SYSTEM_DIR, "sys")                   # sistemski programi (login, desktop, ...)
HELPERS_DIR = os.path.join(SYSTEM_DIR, "helpers")
COCKZ_LIB_DIR = os.path.join(LIB_DIR, "cockz")
APPS_DIR = os.path.join(USR_DIR, "bin")                     # instalirane aplikacije
BIN_DIR = APPS_DIR
LIBS_DIR = os.path.join(LIB_DIR, "modules")                 # "libovi" / kernel ekstenzije
STORE_DIR = os.path.join(USR_DIR, "share", "store")
VAR_DIR = os.path.join(PARTITION, "var")
LOGS_DIR = os.path.join(VAR_DIR, "log")
STATE_DIR = os.path.join(VAR_DIR, "lib", "cockyos")
RUN_DIR = os.path.join(VAR_DIR, "run")
HOME_DIR = os.path.join(PARTITION, "home")
ROOT_HOME = os.path.join(PARTITION, "root")
TMP_DIR = os.path.join(PARTITION, "tmp")
OPT_DIR = os.path.join(PARTITION, "opt")
MNT_DIR = os.path.join(PARTITION, "mnt")

# zadani simbolički linkovi: (ime u / , cilj)
DEFAULT_LINKS = (("bin", "usr/bin"), ("lib", "usr/lib"), ("sbin", "usr/bin"))
SYSTEM_DIRS = (BOOT_DIR, ETC_DIR, TRUST_DIR, APPS_DIR, LIB_DIR, SYSTEM_DIR, LIBS_DIR, STORE_DIR, LOGS_DIR, STATE_DIR,
               RUN_DIR, HOME_DIR, TMP_DIR, OPT_DIR, MNT_DIR)      # /root nastaje tek kad se stvori root račun


def _find_cache():
    """COCKYCACHE je zasebna 'particija' pored COCKYOS foldera (env COCKYCACHE ima prednost)."""
    env = os.environ.get("COCKYCACHE")
    if env:
        return os.path.abspath(env)
    return os.path.join(LOADER_ROOT, "COCKYCACHE")


CACHE_DIR = _find_cache()


def ensure():
    for d in SYSTEM_DIRS:
        os.makedirs(d, exist_ok=True)
    from . import vfs
    for name, target in DEFAULT_LINKS:
        link = os.path.join(PARTITION, name)
        if not os.path.lexists(link):
            vfs.symlink("/" + target, link)
