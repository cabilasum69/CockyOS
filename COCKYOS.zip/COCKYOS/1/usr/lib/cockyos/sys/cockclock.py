"""Lock screen (sat) za CockyOS. Login je u cocklogin.py."""
import sys
import time

from kernel.console import clear, center, term_size, kbhit, getch, cbreak

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MONTHS = ["January", "February", "March", "April", "May", "June", "July",
          "August", "September", "October", "November", "December"]

# Veliki ASCII brojevi za sat
DIGITS = {
    "0": ["█████", "█   █", "█   █", "█   █", "█████"],
    "1": ["  █  ", " ██  ", "  █  ", "  █  ", "█████"],
    "2": ["█████", "    █", "█████", "█    ", "█████"],
    "3": ["█████", "    █", "█████", "    █", "█████"],
    "4": ["█   █", "█   █", "█████", "    █", "    █"],
    "5": ["█████", "█    ", "█████", "    █", "█████"],
    "6": ["█████", "█    ", "█████", "█   █", "█████"],
    "7": ["█████", "    █", "   █ ", "  █  ", "  █  "],
    "8": ["█████", "█   █", "█████", "█   █", "█████"],
    "9": ["█████", "█   █", "█████", "    █", "█████"],
    ":": ["     ", "  █  ", "     ", "  █  ", "     "],
}


def big_clock(text):
    rows = ["", "", "", "", ""]
    for ch in text:
        glyph = DIGITS.get(ch, ["     "] * 5)
        for i in range(5):
            rows[i] += glyph[i] + "  "
    return rows


def draw_lock_screen():
    now = time.localtime()
    clock = time.strftime("%H:%M", now)
    date = f"{DAYS[now.tm_wday]}, {now.tm_mday} {MONTHS[now.tm_mon - 1]} {now.tm_year}"

    cols, lines = term_size()
    out = []
    out.extend([""] * max((lines - 12) // 2, 0))
    for row in big_clock(clock):
        out.append(center(row, cols))
    out.append("")
    out.append(center(date, cols))
    out.append("")
    out.append(center("CockyOS", cols))
    out.append("")
    out.append(center("[ Press any key to unlock ]", cols))

    sys.stdout.write("\033[H" + "\n".join(line.ljust(cols) for line in out))
    sys.stdout.flush()


def lock_screen():
    """Prikazuje sat uživo dok korisnik ne pritisne tipku."""
    clear()
    last = ""
    with cbreak():
        while True:
            stamp = time.strftime("%H:%M")
            if stamp != last:
                clear()
                last = stamp
            draw_lock_screen()

            for _ in range(10):
                if kbhit():
                    getch()
                    return
                time.sleep(0.05)
