"""Shell CockyOS-a nakon prijave (Linux-stil). Root vidi cijelu particiju '/', obični korisnik samo svoj dom (~).

Putanje: ~ = dom, /x = od korijena kaveza, relativne od trenutne mape. Linkovi (ln -s) se prate; ne mogu izaći iz kaveza.
"""
import fnmatch
import getpass
import os
import platform
import shlex
import shutil
import time

import cockz as cockzlib
import kernel
from helpers import fsx
from kernel import apps, cache, cockz, paths, perms, trust, users, vfs
from kernel.console import clear
from kernel.users import is_admin

log = kernel.log.get("CockyOS.desk")

LOCK = "__LOCK__"
SHUTDOWN = "__SHUTDOWN__"

HELP = """Files & folders
  ls [-l] [-a] [-h] [path]   list (-l long, -a hidden, -h human sizes)       tree [-a] [-L n] [path]
  cd [path]                  change dir (cd = home, cd - = previous)         pwd
  mkdir [-p] <dir>           create folder       touch <file>               create empty file / update time
  cat <file>                 print file          head|tail [-n N] <file>    first / last lines
  grep [-i] [-n] <text> <file...>                wc <file>                  lines, words, bytes
  write|append <file>        type text, finish with a line containing only .
  cp [-r] <from> <to>   mv <from> <to>   rm [-r] <path>   (rm on a link removes only the link)
  find [path] [-name pat] [-type f|d|l]          stat <path>   du [-h] [path]

Links
  ln -s <target> <link>      create a symbolic link (works without admin rights; stays inside your jail)
  readlink <link>            show where a link points

System
  uname [-a]   hostname   id   whoami   env   date   df   mount   ps   kill <pid>   lsmod   which <app>
  ver   clear   passwd [user]   cache [clear]   dmesg [n] (root)   lock   shutdown

Apps & packages (.cockz)
  apps   run <app> [args]   start <app> [args]   perms <app>   verify <file.cockz>
  cockz info|list|verify|unpack|export-zip|pack|keygen ...      (see: cockz help)

Root only
  install <file.cockz>   uninstall <app>   trust [add|remove ...]   users   adduser <name>   deluser <name>"""

COCKZ_HELP = """cockz <command>   (library: /usr/lib/cockz, also usable outside the OS: python -m cockz)
  info <file>                    kind, signature, permissions, files
  list <file>                    files with size and compression
  verify <file>                  signature + hash of every file
  unpack <file> [dir] [--force]  decompile a package (refuses a bad signature; --force for unsigned/unknown key)
  export-zip <file> [out.zip]    plain zip for 7-Zip (no signature, viewing only)
  pack <dir> [out.cockz] [--key X.key]   pack a folder (app.json -> app, lib.json -> lib)
  keygen <name>                  new key pair <name>.key (secret) + <name>.pub in the current folder"""


def _fmt_size(n, human):
    return fsx.human_size(n) if human else str(n)


class Shell:
    def __init__(self, username):
        self.username = username
        self.is_root = is_admin(username)
        self.home = os.path.realpath(users.user_dir(username))
        os.makedirs(self.home, exist_ok=True)
        # root vidi cijelu particiju ('/'), ostali samo svoj dom
        self.jail = os.path.realpath(paths.PARTITION) if self.is_root else self.home
        rel = os.path.relpath(self.home, self.jail).replace("\\", "/")
        self.home_rel = "" if rel == "." else rel
        self.cwd = self.home_rel            # logička putanja relativna na kavez (bez početne '/')
        self.oldpwd = self.cwd
        # ove mape se ne smiju obrisati ni kao root
        self.protected = {os.path.realpath(p) for p in (
            paths.PARTITION, paths.BOOT_DIR, paths.ETC_DIR, paths.TRUST_DIR, paths.USR_DIR, paths.APPS_DIR,
            paths.LIB_DIR, paths.SYSTEM_DIR, paths.KERNEL_DIR, paths.SYS_DIR, paths.HELPERS_DIR,
            paths.COCKZ_LIB_DIR, paths.LIBS_DIR, paths.STORE_DIR, paths.VAR_DIR, paths.LOGS_DIR,
            paths.HOME_DIR, paths.ROOT_HOME, paths.TMP_DIR, paths.OPT_DIR, paths.MNT_DIR, self.home)}

    def _need_root(self):
        if not self.is_root:
            raise PermissionError("Permission denied: root only.")

    # ---------- putanje ----------
    @staticmethod
    def _split(p):
        return [x for x in p.split("/") if x not in ("", ".")]

    def lpath(self, p):
        """Korisnički unos -> logička putanja relativna na kavez (prati '..', '~', '/')."""
        p = (p or "").replace("\\", "/")
        if p == "~" or p.startswith("~/"):
            parts = self._split(self.home_rel) + self._split(p[1:])
        elif p.startswith("/"):
            if not self.is_root:                      # korisnik: /home/<ja>/x == ~/x, ostalo je od korijena doma
                mine = "/home/" + self.username
                if p == mine or p.startswith(mine + "/"):
                    p = p[len(mine):]
            parts = self._split(p)
        else:
            parts = self._split(self.cwd) + self._split(p)
        stack = []
        for x in parts:
            if x == "..":
                if stack:
                    stack.pop()
            else:
                stack.append(x)
        return "/".join(stack)

    def resolve(self, p, follow_last=True):
        """Prava OS putanja za korisnički unos; baca PermissionError ako bi izašla iz kaveza."""
        try:
            return vfs.resolve(self.jail, self.lpath(p), follow_last)
        except vfs.LinkError as e:
            raise PermissionError(str(e))

    def show(self, logical):
        h = self.home_rel
        if self.is_root:
            if logical == h:
                return "~"
            if h and logical.startswith(h + "/"):
                return "~/" + logical[len(h) + 1:]
            return "/" + logical
        return "~" + ("/" + logical if logical else "")

    def absolute(self, logical):
        if self.is_root:
            return "/" + logical
        return "/home/%s%s" % (self.username, "/" + logical if logical else "")

    def prompt(self):
        return "%s@cockyos:%s%s " % (self.username, self.show(self.cwd), "#" if self.is_root else "$")

    # ---------- datoteke ----------
    def cmd_help(self, args):
        print(HELP)

    @staticmethod
    def _flags(args, known):
        """Odvaja kratke zastavice (-lah) od ostalih argumenata. Vraća (set_zastavica, ostalo)."""
        flags, rest = set(), []
        for a in args:
            if a.startswith("-") and len(a) > 1 and not a[1:].isdigit() and all(c in known for c in a[1:]):
                flags.update(a[1:])
            else:
                rest.append(a)
        return flags, rest

    def _entry_line(self, it, long, human):
        mark = "l" if it["link"] is not None else ("d" if it["is_dir"] else "-")
        name = it["name"] + ("/" if it["is_dir"] and it["link"] is None else "")
        if it["link"] is not None:
            name += " -> " + it["link"]
        if not long:
            return name
        return "%s %9s  %s  %s" % (mark, "" if it["is_dir"] else _fmt_size(it["size"], human), fsx.fmt_time(it["mtime"]), name)

    def cmd_ls(self, args):
        flags, rest = self._flags(args, "lah")
        path = self.resolve(rest[0]) if rest else self.resolve(".")
        if rest and not os.path.exists(path):                    # pokvaren link: pokaži sam link
            raw = self.resolve(rest[0], follow_last=False)
            if vfs.is_link(raw):
                print(self._entry_line({"name": os.path.basename(raw), "is_dir": False, "size": 0,
                                        "mtime": os.path.getmtime(raw), "link": vfs.read_link(raw)}, "l" in flags, "h" in flags))
                return
        if os.path.isfile(path):
            it = {"name": os.path.basename(path), "is_dir": False, "size": os.path.getsize(path),
                  "mtime": os.path.getmtime(path), "link": vfs.read_link(path)}
            print(self._entry_line(it, "l" in flags, "h" in flags))
            return
        if not os.path.isdir(path):
            print("ls: no such file or directory")
            return
        items = [i for i in fsx.list_dir(path, self.jail) if "a" in flags or not i["name"].startswith(".")]
        if not items:
            return
        if "l" in flags:
            print("total %d" % len(items))
            for it in items:
                print(self._entry_line(it, True, "h" in flags))
        else:
            for it in items:
                print(self._entry_line(it, False, False))

    def cmd_tree(self, args):
        flags, rest = self._flags(args, "a")
        depth = 4
        if "-L" in rest:
            i = rest.index("-L")
            try:
                depth = max(1, int(rest[i + 1]))
            except (IndexError, ValueError):
                print("Usage: tree [-a] [-L depth] [path]")
                return
            del rest[i:i + 2]
        start = self.resolve(rest[0] if rest else ".")
        if not os.path.isdir(start):
            print("tree: not a directory")
            return
        print(self.show(self.lpath(rest[0] if rest else ".")))
        count = {"n": 0, "dirs": 0, "files": 0}

        def walk(path, prefix, d):
            items = [i for i in fsx.list_dir(path, self.jail) if "a" in flags or not i["name"].startswith(".")]
            for idx, it in enumerate(items):
                if count["n"] >= 2000:
                    return
                count["n"] += 1
                last = idx == len(items) - 1
                print(prefix + ("└── " if last else "├── ") + self._entry_line(it, False, False))
                if it["is_dir"] and it["link"] is None:
                    count["dirs"] += 1
                    if d < depth:
                        walk(os.path.join(path, it["name"]), prefix + ("    " if last else "│   "), d + 1)
                else:
                    count["files"] += 1
        walk(start, "", 1)
        print("\n%d directories, %d files%s" % (count["dirs"], count["files"], "  (truncated)" if count["n"] >= 2000 else ""))

    def cmd_cd(self, args):
        if args and args[0] == "-":
            self.cwd, self.oldpwd = self.oldpwd, self.cwd
            print(self.show(self.cwd))
            return
        target = self.lpath(args[0]) if args else self.home_rel
        if os.path.isdir(vfs.resolve(self.jail, target)):
            self.oldpwd, self.cwd = self.cwd, target
        else:
            print("cd: no such directory")

    def cmd_pwd(self, args):
        print(self.absolute(self.cwd))

    def cmd_mkdir(self, args):
        flags, rest = self._flags(args, "p")
        if not rest:
            print("Usage: mkdir [-p] <dir>")
            return
        path = self.resolve(rest[0])
        if os.path.exists(path):
            if "p" not in flags:
                print("mkdir: already exists")
            return
        (os.makedirs if "p" in flags else os.mkdir)(path)

    def cmd_touch(self, args):
        if not args:
            print("Usage: touch <file>")
            return
        path = self.resolve(args[0])
        if os.path.isdir(path):
            return
        with open(path, "a"):
            os.utime(path, None)

    def _read_text(self):
        print("(type text, finish with a line containing only .)")
        lines = []
        while True:
            line = input()
            if line == ".":
                break
            lines.append(line)
        return "\n".join(lines) + ("\n" if lines else "")

    def cmd_write(self, args, mode="w"):
        if not args:
            print("Usage: write <file>" if mode == "w" else "Usage: append <file>")
            return
        path = self.resolve(args[0])
        if os.path.isdir(path):
            print("That is a folder.")
            return
        text = self._read_text()
        with open(path, mode, encoding="utf-8") as f:
            f.write(text)
        print("Saved.")

    def cmd_append(self, args):
        self.cmd_write(args, mode="a")

    def _text_lines(self, name):
        path = self.resolve(name)
        if not os.path.isfile(path):
            raise FileNotFoundError("%s: no such file" % name)
        with open(path, "r", encoding="utf-8") as f:
            return f.read().splitlines()

    def cmd_cat(self, args):
        if not args:
            print("Usage: cat <file>")
            return
        try:
            print("\n".join(self._text_lines(args[0])))
        except UnicodeDecodeError:
            print("cat: not a text file")
        except FileNotFoundError as e:
            print("cat: %s" % e)

    def _head_tail(self, args, tail):
        n, rest = 10, list(args)
        if "-n" in rest:
            i = rest.index("-n")
            try:
                n = int(rest[i + 1])
            except (IndexError, ValueError):
                print("Usage: %s [-n N] <file>" % ("tail" if tail else "head"))
                return
            del rest[i:i + 2]
        if not rest:
            print("Usage: %s [-n N] <file>" % ("tail" if tail else "head"))
            return
        try:
            lines = self._text_lines(rest[0])
        except (UnicodeDecodeError, FileNotFoundError) as e:
            print("%s: %s" % ("tail" if tail else "head", e if isinstance(e, FileNotFoundError) else "not a text file"))
            return
        print("\n".join(lines[-n:] if tail else lines[:n]))

    def cmd_head(self, args):
        self._head_tail(args, False)

    def cmd_tail(self, args):
        self._head_tail(args, True)

    def cmd_wc(self, args):
        if not args:
            print("Usage: wc <file>")
            return
        path = self.resolve(args[0])
        if not os.path.isfile(path):
            print("wc: no such file")
            return
        with open(path, "rb") as f:
            data = f.read()
        text = data.decode("utf-8", "replace")
        print(" %d %d %d %s" % (text.count("\n"), len(text.split()), len(data), args[0]))

    def cmd_grep(self, args):
        flags, rest = self._flags(args, "in")
        if len(rest) < 2:
            print("Usage: grep [-i] [-n] <text> <file...>")
            return
        needle = rest[0].lower() if "i" in flags else rest[0]
        for name in rest[1:]:
            try:
                lines = self._text_lines(name)
            except (UnicodeDecodeError, FileNotFoundError):
                print("grep: %s: cannot read" % name)
                continue
            for no, line in enumerate(lines, 1):
                if needle in (line.lower() if "i" in flags else line):
                    print("%s%s%s" % (name + ":" if len(rest) > 2 else "", "%d:" % no if "n" in flags else "", line))

    def cmd_rm(self, args):
        flags, rest = self._flags(args, "rf")
        if not rest:
            print("Usage: rm [-r] <path>")
            return
        path = self.resolve(rest[0], follow_last=False)
        if vfs.is_link(path) or os.path.islink(path):
            os.remove(path)                               # briše samo link, ne cilj
            return
        if os.path.realpath(path) in self.protected:
            print("rm: refusing to delete a protected system folder")
            return
        if os.path.isfile(path):
            os.remove(path)
        elif os.path.isdir(path):
            if "r" not in flags and input("Delete folder '%s' and everything in it? [y/N] " % rest[0]).strip().lower() != "y":
                return
            shutil.rmtree(path)
            if not os.path.isdir(vfs.resolve(self.jail, self.cwd)):
                self.cwd = self.home_rel
        else:
            print("rm: no such file or folder")

    def cmd_mv(self, args):
        if len(args) != 2:
            print("Usage: mv <from> <to>")
            return
        src, dst = self.resolve(args[0], False), self.resolve(args[1])
        if not os.path.lexists(src):
            print("mv: no such file or folder")
            return
        if os.path.realpath(src) in self.protected:
            print("mv: refusing to move a protected system folder")
            return
        if os.path.isdir(dst):
            dst = os.path.join(dst, os.path.basename(src))
        shutil.move(src, dst)

    def cmd_cp(self, args):
        flags, rest = self._flags(args, "r")
        if len(rest) != 2:
            print("Usage: cp [-r] <from> <to>")
            return
        src, dst = self.resolve(rest[0], False), self.resolve(rest[1])
        if not os.path.lexists(src):
            print("cp: no such file or folder")
            return
        if os.path.isdir(dst):
            dst = os.path.join(dst, os.path.basename(src))
        if os.path.isdir(src) and not vfs.is_link(src):
            if "r" not in flags:
                print("cp: -r needed to copy a folder")
                return
            if dst == src or dst.startswith(src + os.sep):
                print("cp: can't copy a folder into itself")
                return
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)

    def cmd_ln(self, args):
        flags, rest = self._flags(args, "sf")
        if "s" not in flags:
            print("ln: only symbolic links are supported (use: ln -s <target> <link>)")
            return
        if len(rest) != 2:
            print("Usage: ln -s <target> <link>")
            return
        target, link = rest
        link_path = self.resolve(link, follow_last=False)
        if os.path.isdir(link_path):                        # ln -s cilj mapa/  -> mapa/<ime cilja>
            link_path = os.path.join(link_path, os.path.basename(target.rstrip("/")) or "link")
        if os.path.lexists(link_path):
            if "f" not in flags:
                print("ln: '%s' already exists (use -f to replace)" % link)
                return
            os.remove(link_path)
        t = target.replace("\\", "/")
        if t.startswith("~"):
            t = "/" + "/".join(self._split(self.home_rel) + self._split(t[1:]))
        vfs.resolve(self.jail, self.lpath(target) if t.startswith("/") or True else t)   # mora ostati u kavezu
        vfs.symlink(t, link_path)
        print("%s -> %s" % (link, t))

    def cmd_readlink(self, args):
        if not args:
            print("Usage: readlink <link>")
            return
        t = vfs.read_link(self.resolve(args[0], follow_last=False))
        print(t if t is not None else "readlink: not a link")

    def cmd_stat(self, args):
        if not args:
            print("Usage: stat <path>")
            return
        path = self.resolve(args[0], follow_last=False)
        if not os.path.lexists(path):
            print("stat: no such file or folder")
            return
        link = vfs.read_link(path)
        st = os.stat(path)
        kind = "symbolic link" if link is not None else ("directory" if os.path.isdir(path) else "regular file")
        print("  File: %s%s" % (args[0], " -> " + link if link is not None else ""))
        print("  Type: %s" % kind)
        print("  Size: %d bytes (%s)" % (st.st_size, fsx.human_size(st.st_size)))
        print("Modify: %s" % time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime)))
        print(" Owner: %s" % (self.username if self.home in os.path.realpath(path) else "root"))

    def cmd_find(self, args):
        rest, pattern, ftype = list(args), None, None
        for opt in ("-name", "-type"):
            if opt in rest:
                i = rest.index(opt)
                try:
                    val = rest[i + 1]
                except IndexError:
                    print("find: %s needs a value" % opt)
                    return
                del rest[i:i + 2]
                if opt == "-name":
                    pattern = val
                else:
                    ftype = val
        start_l = self.lpath(rest[0] if rest else ".")
        start = self.resolve(rest[0] if rest else ".")
        if not os.path.isdir(start):
            print("find: not a directory")
            return
        found = 0

        def walk(real, logical):
            nonlocal found
            for it in fsx.list_dir(real, self.jail):
                if found >= 5000:
                    return
                lp = (logical + "/" + it["name"]).lstrip("/")
                kind = "l" if it["link"] is not None else ("d" if it["is_dir"] else "f")
                if (pattern is None or fnmatch.fnmatch(it["name"].lower(), pattern.lower())) and (ftype is None or ftype == kind):
                    print(self.show(lp) if self.is_root else self.show(lp))
                    found += 1
                if kind == "d":
                    walk(os.path.join(real, it["name"]), lp)
        walk(start, start_l)

    def cmd_du(self, args):
        flags, rest = self._flags(args, "h")
        start = self.resolve(rest[0] if rest else ".")
        if not os.path.exists(start):
            print("du: no such file or folder")
            return
        rows = []
        for it in fsx.list_dir(start, self.jail) if os.path.isdir(start) else []:
            full = os.path.join(start, it["name"])
            size = 0
            if it["is_dir"] and it["link"] is None:
                for base, _d, names in os.walk(full):
                    for n in names:
                        try:
                            size += os.path.getsize(os.path.join(base, n))
                        except OSError:
                            pass
            elif it["link"] is None:
                size = it["size"]
            rows.append((size, it["name"] + ("/" if it["is_dir"] else "")))
        for size, name in sorted(rows, reverse=True)[:40]:
            print("%10s  %s" % (_fmt_size(size, "h" in flags), name))
        print("%10s  total" % _fmt_size(sum(r[0] for r in rows), "h" in flags))

    def cmd_clear(self, args):
        clear()

    def cmd_time(self, args):
        print(time.strftime("%A, %d.%m.%Y  %H:%M:%S"))

    cmd_date = cmd_time

    # ---------- sustav ----------
    def cmd_whoami(self, args):
        print(self.username)

    def cmd_id(self, args):
        print("user=%s home=%s groups=%s" % (self.username, self.absolute(self.home_rel) if self.is_root else "/home/" + self.username,
                                           "wheel,users" if self.is_root else "users"))

    def cmd_hostname(self, args):
        print("cockyos")

    def cmd_uname(self, args):
        d = kernel.hal.describe()
        if args and args[0] == "-a":
            print("CockyOS cockyos %s %s %s Python/%s (%s)" % (kernel.VERSION, kernel.hal.ARCH, kernel.hal.NAME,
                                                             platform.python_version(), "bundled" if d["bundled_runtime"] else "system"))
        else:
            print("CockyOS")

    def cmd_env(self, args):
        for k, v in (("USER", self.username), ("HOME", self.absolute(self.home_rel) if not self.is_root else "/root"),
                     ("PWD", self.absolute(self.cwd)), ("SHELL", "cockdesk"), ("PATH", "/usr/bin"),
                     ("HOSTNAME", "cockyos"), ("LANG", "C.UTF-8")):
            print("%s=%s" % (k, v))

    def cmd_df(self, args):
        rows = [("/", paths.PARTITION), ("/var/cache (COCKYCACHE)", paths.CACHE_DIR)]
        print("%-26s %10s %10s %10s %5s" % ("Filesystem", "Size", "Used", "Avail", "Use%"))
        for name, p in rows:
            try:
                u = shutil.disk_usage(p)
                print("%-26s %10s %10s %10s %4d%%" % (name, fsx.human_size(u.total), fsx.human_size(u.used),
                                                     fsx.human_size(u.free), round(100.0 * u.used / u.total)))
            except OSError:
                print("%-26s (unavailable)" % name)

    def cmd_mount(self, args):
        print("COCKYOS/%s on / type cockfs (rw)" % paths.PARTITION_NAME)
        print("COCKYCACHE on /var/cache type cockcache (rw)")
        for name, target in paths.DEFAULT_LINKS:
            print("/%s -> /%s (link)" % (name, target))

    def cmd_ps(self, args):
        rows = apps.running()
        print("%7s  %-14s %-10s %-9s %s" % ("PID", "APP", "USER", "STARTED", "MODE"))
        for pid, app, user, started, bg in rows:
            print("%7d  %-14s %-10s %-9s %s" % (pid, app, user or "-", time.strftime("%H:%M:%S", time.localtime(started)),
                                             "background" if bg else "foreground"))
        if not rows:
            print("(no apps running from this session)")

    def cmd_kill(self, args):
        if not args or not args[0].isdigit():
            print("Usage: kill <pid>   (see: ps)")
            return
        pid = int(args[0])
        owner = apps.PROCESSES.get(pid, {}).get("user")
        if owner and owner != self.username and not self.is_root:
            print("kill: not your process")
            return
        print("Terminated." if apps.kill(pid) else "kill: no such running app (only apps started from this session can be killed)")

    def cmd_lsmod(self, args):
        from helpers import libs
        act = libs.active()
        print("%-14s %s" % ("MODULE", "PATH"))
        for lib_id, path in sorted(act.items()):
            print("%-14s %s" % (lib_id, path))
        for name, why in libs.problems().items():
            print("%-14s NOT LOADED: %s" % (name, why))
        if not act and not libs.problems():
            print("(no modules in /usr/lib/modules)")

    def cmd_which(self, args):
        if not args:
            print("Usage: which <app>")
            return
        try:
            info = apps.find(args[0])
            print("/usr/bin/%s" % os.path.basename(info.path))
        except apps.AppError as e:
            print("which: %s" % e)

    def cmd_dmesg(self, args):
        self._need_root()
        n = int(args[0]) if args and args[0].isdigit() else 30
        path = kernel.log.LOG_FILE
        if not path or not os.path.isfile(path):
            print("(no log yet)")
            return
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f.read().splitlines()[-n:]:
                print(line[:200])

    def cmd_cockz(self, args):
        if not args or args[0] in ("help", "-h", "--help"):
            print(COCKZ_HELP)
            return
        sub, rest = args[0], list(args[1:])
        try:
            if sub == "keygen":
                if len(rest) != 1:
                    print("Usage: cockz keygen <name>")
                    return
                kp, pp = trust.generate_keypair(rest[0], self.resolve("."))
                print("Created %s.key (SECRET - never share it) and %s.pub (share this one)." % (rest[0], rest[0]))
            elif sub == "pack":
                seed = None
                if "--key" in rest:
                    i = rest.index("--key")
                    seed = trust.load_private(self.resolve(rest[i + 1]))
                    del rest[i:i + 2]
                if not rest:
                    print("Usage: cockz pack <dir> [out.cockz] [--key X.key]")
                    return
                src = self.resolve(rest[0])
                out = self.resolve(rest[1]) if len(rest) > 1 else os.path.join(self.resolve("."), os.path.basename(src) + cockz.EXT)
                n = cockz.pack(src, out, seed)
                print("Packed %d files -> %s (%s)" % (n, self.show(self.lpath(rest[1]) if len(rest) > 1 else self.lpath(os.path.basename(src) + cockz.EXT)),
                                                      "signed" if seed else "UNSIGNED"))
            elif sub in ("info", "list", "verify", "unpack", "export-zip"):
                force = "--force" in rest
                rest = [r for r in rest if r != "--force"]
                if not rest:
                    print("Usage: cockz %s <file.cockz>" % sub)
                    return
                pkg = cockz.open_package(self.resolve(rest[0]))
                ver = pkg.verify(trust.trusted_keys())
                if sub == "info":
                    print("kind       : %s\nfiles      : %d\nsignature  : %s" % (pkg.kind, len(pkg.files), ver.describe()))
                    for k in ("name", "version", "description"):
                        if pkg.meta.get(k):
                            print("%-11s: %s" % (k, pkg.meta[k]))
                    if pkg.meta.get("permissions"):
                        print("permissions: %s" % ", ".join(pkg.meta["permissions"]))
                elif sub == "list":
                    print("signature: %s" % ver.describe())
                    for e in pkg.files:
                        print("%9d  %-8s %s" % (e["size"], e["method"], e["path"]))
                elif sub == "verify":
                    pkg.verify_all()
                    print("%s: %s, all %d file hashes OK" % (rest[0], ver.describe(), len(pkg.files)))
                elif sub == "unpack":
                    if ver.status == cockz.STATUS_BAD:
                        raise cockz.CockzError("signature check FAILED: %s" % ver.describe())
                    if not ver.ok and not force:
                        raise cockz.CockzError("package is %s (use --force to unpack anyway)" % ver.describe())
                    dest = rest[1] if len(rest) > 1 else os.path.splitext(os.path.basename(rest[0]))[0]
                    print("Unpacked %d files into %s" % (pkg.extract(self.resolve(dest)), dest))
                else:
                    out = rest[1] if len(rest) > 1 else os.path.splitext(rest[0])[0] + ".zip"
                    n = cockzlib.export_zip(self.resolve(rest[0]), self.resolve(out))
                    print("Exported %d files -> %s (no signature; for viewing only)" % (n, out))
            else:
                print("cockz: unknown command '%s' (try: cockz help)" % sub)
        except (cockz.CockzError, trust.TrustError, OSError) as e:
            print("cockz: %s" % e)

    def cmd_passwd(self, args):
        target = self.username
        if args:
            self._need_root()
            target = args[0]
            if not users.exists(target):
                print("No such user.")
                return
        resetting_other = target != self.username
        if users.has_password(target) and not resetting_other:
            if not users.check_password(target, getpass.getpass("Current password: ").strip()):
                print("Wrong password.")
                return
        new = getpass.getpass("New password (empty = none): ").strip()
        if new and getpass.getpass("Repeat new password: ").strip() != new:
            print("Passwords don't match.")
            return
        users.set_password(target, new)
        print("Password changed." if new else "Password removed.")
        log.info("'%s' changed password of '%s'", self.username, target)  # lozinka se ne logira

    def cmd_ver(self, args):
        print("CockyOS kernel %s | partition %s | %s | Python %s%s" % (
            kernel.VERSION, paths.PARTITION_NAME, kernel.hal.RUNTIME_ID, platform.python_version(),
            " (bundled)" if kernel.hal.describe()["bundled_runtime"] else " (system)"))

    # ---------- aplikacije i cache ----------
    def cmd_apps(self, args):
        found = apps.list_installed()
        if not found:
            print(" (no apps installed)")
        for a in found:
            tag = {"official": "official", "trusted": "trusted", "untrusted": "UNTRUSTED",
                   "unsigned": "UNSIGNED", "bad": "BAD!"}[a.verification.status]
            print(" %-14s %-22s v%-5s [%s]  %s" % (a.id, a.name, a.version, tag, a.description))

    def _run_app(self, args, background):
        if not args:
            print("Usage: %s <app> [args]" % ("start" if background else "run"))
            return
        try:
            if background:
                proc = apps.spawn(args[0], self.username, args[1:])
                print("Started '%s' in the background (pid %d)." % (args[0], proc.pid))
            else:
                rc = apps.run(args[0], self.username, args[1:])
                if rc not in (0, None):
                    print("(app finished with code %s)" % rc)
        except apps.AppError as e:
            print("Error: %s" % e)
        except KeyboardInterrupt:
            print("\n(app interrupted)")

    def cmd_run(self, args):
        self._run_app(args, background=False)

    def cmd_start(self, args):
        self._run_app(args, background=True)

    def _ask_perms(self, info, offered):
        print()
        print("Package   : %s v%s (%s)" % (info.name, info.version, info.id))
        print("Signature : %s" % info.verification.describe())
        asked = list(info.permissions)
        if not asked:
            print("Permissions: none requested.")
        else:
            print("Permissions requested:")
            for p in asked:
                print("  %s%s" % (perms.describe(p), "" if p in offered else "   <- NOT offered (package is not signed by a trusted key)"))
        if input("Install with %s? [y/N] " % ("these permissions" if offered else "no permissions")).strip().lower() != "y":
            return None
        return offered

    def cmd_install(self, args):
        self._need_root()
        if not args:
            print("Usage: install <file.cockz>")
            return
        src = self.resolve(args[0])
        allow_unsigned = False
        try:
            info = apps.inspect(src)
            if not info.signed:
                print("WARNING: this package is %s." % info.verification.describe())
                print("Anything you install runs as normal Python code; only continue if you wrote or trust it.")
                if input("Install it anyway (without dangerous permissions)? [y/N] ").strip().lower() != "y":
                    print("Cancelled.")
                    return
                allow_unsigned = True
            info, replaced, chosen = apps.install(src, self._ask_perms, allow_unsigned)
        except apps.AppError as e:
            print("Error: %s" % e)
            return
        print("%s '%s' v%s with permissions: %s." % ("Updated" if replaced else "Installed", info.id, info.version,
                                                    ", ".join(chosen) or "none"))
        log.info("'%s' installed '%s' (%s)", self.username, info.id, info.verification.describe())

    def cmd_uninstall(self, args):
        self._need_root()
        if not args:
            print("Usage: uninstall <app>")
            return
        try:
            info = apps.uninstall(args[0])
        except apps.AppError as e:
            print("Error: %s" % e)
            return
        print("Removed '%s'." % info.id)

    def cmd_perms(self, args):
        if not args:
            print("Usage: perms <app>")
            return
        try:
            info = apps.find(args[0])
        except apps.AppError as e:
            print("Error: %s" % e)
            return
        real = apps.current_grants(info)
        print("%s v%s   signature: %s" % (info.name, info.version, info.verification.describe()))
        if not info.permissions:
            print("Asks for no permissions.")
        for p in info.permissions:
            print("  [%s] %s" % ("GRANTED" if p in real else "denied ", perms.describe(p)))

    def cmd_verify(self, args):
        if not args:
            print("Usage: verify <file.cockz>")
            return
        try:
            pkg, ver = trust.verify(self.resolve(args[0]))
        except cockz.CockzError as e:
            print("Error: %s" % e)
            return
        print("Kind      : %s" % pkg.kind)
        print("Files     : %d" % len(pkg.files))
        print("Signature : %s" % ver.describe())
        try:
            pkg.verify_all()
            print("Hashes    : all %d files match" % len(pkg.files))
        except cockz.CockzError as e:
            print("Hashes    : FAILED - %s" % e)

    def cmd_trust(self, args):
        if args and args[0].lower() in ("add", "remove"):
            self._need_root()
            try:
                if args[0].lower() == "add":
                    if len(args) != 3:
                        print("Usage: trust add <name> <file.pub|file.key>")
                        return
                    _n, pub = trust.read_pub_file(self.resolve(args[2]))
                    print("Key fingerprint: %s" % cockz.key_id(bytes.fromhex(pub)))
                    if input("Trust packages signed with this key? [y/N] ").strip().lower() != "y":
                        print("Cancelled.")
                        return
                    trust.add_key(args[1], pub)
                    print("Trusted key '%s' added." % args[1])
                else:
                    if len(args) != 2:
                        print("Usage: trust remove <name>")
                        return
                    trust.remove_key(args[1])
                    print("Key removed.")
            except (trust.TrustError, OSError, ValueError, KeyError) as e:
                print("Error: %s" % e)
            return
        for pub, k in trust.trusted_keys().items():
            print(" %-14s %-9s %s" % (k["name"], k["level"], cockz.key_id(bytes.fromhex(pub))))

    def cmd_cache(self, args):
        if args and args[0].lower() == "clear":
            self._need_root()
            files, size = cache.clear()
            print("COCKYCACHE cleared (%d files, %.1f KB)." % (files, size / 1024.0))
            log.info("'%s' cleared COCKYCACHE (%d files)", self.username, files)
            return
        st = cache.status()
        print("COCKYCACHE : %s" % st["path"])
        print("Size       : %d files, %.1f KB" % (st["files"], st["bytes"] / 1024.0))
        print("Unpacked   : %s" % (", ".join(st["apps"]) or "(nothing)"))

    # ---------- root komande ----------
    def cmd_root(self, args):
        print("Jail (/)    : %s" % ("whole partition" if self.is_root else "your home only"))
        print("Home        : %s" % self.absolute(self.home_rel) if not self.is_root else "Home        : /root")
        print("Current dir : %s" % self.absolute(self.cwd))
        print("Permissions : %s" % ("ROOT (whole partition + user management)" if self.is_root else "normal user (own home only)"))

    def cmd_users(self, args):
        self._need_root()
        for u in users.get_users():
            tag = "  [root]" if is_admin(u) else ""
            print(f" {u}{tag}   (password: {'yes' if users.has_password(u) else 'no'})")

    def cmd_adduser(self, args):
        self._need_root()
        if not args:
            print("Usage: adduser <name>")
            return
        pw = getpass.getpass("Password (empty = none): ").strip()
        ok, msg = users.create_user(args[0], pw)
        print(msg)
        if ok:
            log.info("root created user '%s'", args[0])

    def cmd_deluser(self, args):
        self._need_root()
        if not args:
            print("Usage: deluser <name>")
            return
        name = args[0]
        if is_admin(name):
            print("The root account can't be deleted.")
            return
        if not users.exists(name):
            print("No such user.")
            return
        if input(f"Delete user '{name}' and ALL their files? [y/N] ").strip().lower() == "y":
            ok, msg = users.delete_user(name)
            log.warning("root deleted user '%s'", name)
            if not os.path.isdir(self.cwd):
                self.cwd = self.home
            print(msg)

    # ---------- glavna petlja ----------
    def run(self):
        clear()
        print("Welcome to CockyOS %s, %s!" % (kernel.VERSION, self.username))
        if self.is_root:
            print("Logged in as ROOT (full permissions).")
        print("Type 'help' for commands.\n")

        while True:
            try:
                line = input(self.prompt()).strip()
            except (KeyboardInterrupt, EOFError):
                print()
                continue
            if not line:
                continue

            try:
                parts = shlex.split(line.replace("\\", "/"))
            except ValueError as e:
                print("Parse error: %s" % e)
                continue

            cmd, args = parts[0].lower(), parts[1:]

            if cmd in ("lock", "logout", "exit"):
                log.info("'%s' -> lock", self.username)
                return LOCK
            if cmd in ("shutdown", "poweroff"):
                log.info("'%s' -> shutdown", self.username)
                return SHUTDOWN

            handler = getattr(self, "cmd_" + cmd.replace("-", "_"), None)
            if handler is None:
                print("Unknown command: %s  (type 'help')" % cmd)
                continue

            if cmd != "passwd":
                log.debug("'%s' ran: %s", self.username, line)
            try:
                handler(args)
            except PermissionError as e:
                print(e)
            except Exception as e:
                log.error("Command '%s' failed", line, exc_info=True)
                print("Error: %s: %s" % (type(e).__name__, e))


def run(username):
    """Vraća LOCK ili SHUTDOWN."""
    return Shell(username).run()
