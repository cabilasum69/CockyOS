"""CockyOS init: diže kernel, radi prvo postavljanje i vrti lock -> login -> desktop petlju."""
import getpass
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
PAR = os.path.dirname(HERE)                  # /usr/lib/cockyos
for _p in (PAR, os.path.dirname(PAR), HERE):  # da rade `import kernel`, `import cockz` i cockclock/cocklogin/cockdesk
    if _p not in sys.path:
        sys.path.insert(0, _p)

import kernel  # noqa: E402
from kernel import console, users  # noqa: E402

log = kernel.log.get("CockyOS.system")


def add_user():
    """Interaktivno dodavanje običnog korisnika."""
    username = input("Enter new username: ").strip()
    password = getpass.getpass("Password (leave empty for none): ").strip()
    ok, msg = users.create_user(username, password)
    print(msg)
    return ok


def first_setup():
    """Root račun i barem jedan običan korisnik moraju postojati."""
    if users.ADMIN_USER not in users.get_users():
        log.info("Root account missing, creating it")
        console.clear()
        print("=== CockyOS First Setup ===\n")
        print("Creating the root account (full permissions).")
        while True:
            pw = getpass.getpass("Set root password (empty = none): ").strip()
            if pw and getpass.getpass("Repeat password: ").strip() != pw:
                print("Passwords don't match, try again.\n")
                continue
            break
        ok, msg = users.create_user(users.ADMIN_USER, pw)
        log.info("Root creation: %s", msg)
        print(msg)
        time.sleep(1)

    while not [u for u in users.get_users() if u != users.ADMIN_USER]:
        log.info("No regular users found, running first-time add_user()")
        console.clear()
        print("=== CockyOS First Setup ===\n")
        print("Create your first (normal) user.\n")
        add_user()
        time.sleep(1)


def fallback_login():
    """Najjednostavniji login ako sys moduli ne rade."""
    while True:
        console.clear()
        print("=== CockyOS Login (fallback) ===\n")
        for u in users.get_users():
            print(" -", u)
        print("\n [L] Login   [A] Add user   [Q] Quit")
        choice = input("\nSelect option: ").strip().lower()
        if choice == "q":
            return
        if choice == "a":
            add_user()
        elif choice == "l":
            name = input("Username: ").strip()
            if not users.exists(name):
                print("User does not exist.")
            elif not users.check_password(name, getpass.getpass("Password: ").strip()):
                print("Wrong password.")
            else:
                console.clear()
                print("Welcome to CockyOS, %s!\n" % name)
                items = os.listdir(users.stuff_dir(name)) if os.path.isdir(users.stuff_dir(name)) else []
                print("Your home:")
                for item in items or ["(empty)"]:
                    print(" -", item)
        time.sleep(1.2)


def start_system():
    verbose = os.environ.get("COCKY_VERBOSE") == "1"
    kernel.boot(verbose=verbose)
    log.info("system.py started (kernel %s)", kernel.VERSION)

    try:
        import cockclock
        import cocklogin
        import cockdesk
        log.info("sys modules imported OK from %s", HERE)
    except BaseException as e:
        if isinstance(e, KeyboardInterrupt):
            raise
        log.error("Could not load sys modules (%s: %s)\n%s", type(e).__name__, e, traceback.format_exc())
        print("Couldn't load system modules.. using fallback login")
        print("(reason: %s: %s)" % (type(e).__name__, e))
        print("(details in log: %s)" % kernel.log.LOG_FILE)
        time.sleep(2)
        fallback_login()
        return

    first_setup()

    if verbose:
        time.sleep(1.5)
    kernel.log.quiet()

    try:
        log.info("Starting lock/login loop")
        while True:
            cockclock.lock_screen()
            user = cocklogin.login()

            if user is None:
                log.info("Back to lock screen from login")
                continue
            if user == cocklogin.SHUTDOWN:
                log.info("Shutdown chosen at login screen")
                break

            log.info("User '%s' logged in", user)
            if cockdesk.run(user) == cockdesk.SHUTDOWN:
                log.info("Shutdown chosen by '%s'", user)
                break
            log.info("User '%s' locked the system", user)

        console.clear()
        print("Shutting down CockyOS...")
        time.sleep(1)
        log.info("Lock/login loop ended normally")
    except KeyboardInterrupt:
        log.info("Interrupted by user (Ctrl+C)")
    except Exception:
        log.error("System loop crashed:\n%s", traceback.format_exc())
        print("System crashed.. using fallback login")
        print("(details in log: %s)" % kernel.log.LOG_FILE)
        time.sleep(2)
        fallback_login()
