"""Login ekran CockyOS-a (odvojeno od lock screena)."""
import time

from kernel import users
from kernel.console import clear, term_size, cprint, cinput, read_password

MAX_ATTEMPTS = 3
LOCKOUT_SECONDS = 10

# Povratne vrijednosti login()
SHUTDOWN = "__SHUTDOWN__"


def login():
    """
    Vraća:
      - username        -> uspješna prijava
      - None            -> korisnik se vratio na lock screen
      - SHUTDOWN        -> korisnik je odabrao gašenje sustava
    """
    while True:
        clear()
        names = users.get_users()

        block = ["=== CockyOS Login ===", ""]
        if names:
            block += ["[%d] %s" % (i, u) for i, u in enumerate(names, 1)]
        else:
            block += ["No users found."]
        block += ["", "[B] Back to lock screen", "[S] Shut down", ""]

        # vertikalno centriranje (+2 reda za prompt i unos)
        lines = term_size()[1]
        print("\n" * max((lines - (len(block) + 2)) // 2, 0), end="")
        for line in block:
            cprint(line)

        choice = cinput("Select user (number or name):")
        low = choice.lower()

        if low == "b":
            return None
        if low == "s":
            return SHUTDOWN

        if choice.isdigit() and 1 <= int(choice) <= len(names):
            username = names[int(choice) - 1]
        elif choice in names:
            username = choice
        else:
            cprint("User does not exist.")
            time.sleep(1.2)
            continue

        if not users.has_password(username):
            return username

        for attempt in range(1, MAX_ATTEMPTS + 1):
            if users.check_password(username, read_password("Password for %s:" % username)):
                return username
            left = MAX_ATTEMPTS - attempt
            if left:
                cprint("Wrong password. %d attempt(s) left." % left)
            else:
                cprint("Too many attempts. Locked for %ds." % LOCKOUT_SECONDS)
                for s in range(LOCKOUT_SECONDS, 0, -1):
                    cprint("Wait %ds" % s)
                    time.sleep(1)
