"""Sigurne putanje i datoteke."""
import os
import shutil
import time


def safe_join(base, rel="", follow_last=True):
    """Spaja base + rel, prati CockyOS linkove i garantira da rezultat ostaje UNUTAR base.
    follow_last=False: zadnja komponenta se ne razrješava (za brisanje/preimenovanje samog linka).
    Baca PermissionError ako bi izašao iz base."""
    from kernel import vfs
    return vfs.resolve(base, rel, follow_last)


def inside(base, path):
    try:
        safe_join(base, os.path.relpath(os.path.realpath(path), os.path.realpath(base)))
        return True
    except (PermissionError, ValueError, OSError):
        return False


def human_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0


def list_dir(path, jail=None):
    """Popis [{name, is_dir, size, mtime, link}] - prvo mape, pa datoteke, abecedno.
    link = cilj ako je stavka CockyOS link (is_dir tada vrijedi za cilj, ako se može razriješiti unutar 'jail')."""
    from kernel import vfs
    out = []
    with os.scandir(path) as it:
        for e in it:
            try:
                st = e.stat()
                link = None
                if e.is_symlink() or (e.is_file() and st.st_size <= vfs.MAX_TARGET + len(vfs.MAGIC)):
                    link = vfs.read_link(e.path)
                is_dir = e.is_dir()
                size = 0 if is_dir else st.st_size
                if link is not None and jail:
                    try:
                        real = vfs.resolve(jail, os.path.relpath(e.path, jail))
                        is_dir = os.path.isdir(real)
                        size = 0 if is_dir else (os.path.getsize(real) if os.path.exists(real) else 0)
                    except (OSError, PermissionError):
                        pass
                out.append({"name": e.name, "is_dir": is_dir, "size": size, "mtime": st.st_mtime, "link": link})
            except OSError:
                continue
    out.sort(key=lambda d: (not d["is_dir"], d["name"].lower()))
    return out


def write_atomic(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".part"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)


def remove(path):
    if os.path.isdir(path) and not os.path.islink(path):
        shutil.rmtree(path)
    else:
        os.remove(path)


def unique_name(folder, name):
    """name, pa 'name (2)', 'name (3)'... dok ne nađe slobodno ime."""
    base, ext = os.path.splitext(name)
    cand, i = name, 2
    while os.path.exists(os.path.join(folder, cand)):
        cand = "%s (%d)%s" % (base, i, ext)
        i += 1
    return cand


def fmt_time(ts):
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))
