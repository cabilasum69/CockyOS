"""Libovi (kernel extensions / Python ekstenzije): potpisani .cockz paketi kind 'lib' u /usr/lib/modules/.

    modules/pillow.cockz  ->  lib.json {"id": "pillow", "name": "Pillow", "version": "...", "path": ""}
                           + sadržaj wheela (PIL/ ...)

Pri bootu kernel svaki lib provjeri (MORA biti potpisan službenim ili povjerenim ključem), raspakira u
COCKYCACHE/libs/<id>-<otisak>/ i doda u sys.path. Nepotpisani ili izmijenjeni libovi se ne učitavaju.
Libove pravi:  python tools/wheel2cockz.py <datoteka.whl>   ili   cockZiper (lib.json u folderu).
"""
import os
import re
import shutil
import sys

from kernel import cockz, log, paths, trust

_log = log.get("CockyOS.libs")
_ID_RE = re.compile(r"[a-z0-9][a-z0-9_-]{0,31}")
_active = {}      # id -> putanja
_problems = {}    # id/ime datoteke -> razlog zašto nije učitan


def cache_root():
    return os.path.join(paths.CACHE_DIR, "libs")


def active():
    return dict(_active)


def problems():
    return dict(_problems)


def is_active(lib_id):
    return lib_id in _active


def activate(path):
    """Učita jedan lib. Vraća njegov id ili None ako ga ne smije učitati (razlog je u problems())."""
    name = os.path.basename(path)
    try:
        pkg = cockz.open_package(path)
        if pkg.kind != "lib":
            raise cockz.CockzError("not a lib package")
        meta = pkg.meta
        lib_id = str(meta.get("id", ""))
        if not _ID_RE.fullmatch(lib_id):
            raise cockz.CockzError("invalid lib id")
        ver = pkg.verify(trust.trusted_keys())
        if not ver.ok:
            raise cockz.CockzError("not loaded: package is %s" % ver.describe())
        digest = pkg.digest().hex()
        dest = os.path.join(cache_root(), "%s-%s" % (lib_id, digest[:12]))
        if not os.path.isfile(os.path.join(dest, ".ok")):
            os.makedirs(cache_root(), exist_ok=True)
            for old in os.listdir(cache_root()):
                if old.startswith(lib_id + "-"):
                    shutil.rmtree(os.path.join(cache_root(), old), ignore_errors=True)
            tmp = dest + ".part"
            shutil.rmtree(tmp, ignore_errors=True)
            pkg.extract(tmp)
            with open(os.path.join(tmp, ".ok"), "w") as f:
                f.write(digest)
            os.rename(tmp, dest)
        sub = str(meta.get("path", "")).replace("\\", "/").strip("/")
        entry = os.path.join(dest, *sub.split("/")) if sub else dest
        if entry not in sys.path:
            sys.path.append(entry)
        _active[lib_id] = entry
        _problems.pop(name, None)
        _log.info("Lib '%s' active (%s) [%s]", lib_id, entry, ver.describe())
        return lib_id
    except (cockz.CockzError, OSError) as e:
        _problems[name] = str(e)
        _log.warning("Lib %s skipped: %s", name, e)
        return None


def activate_all():
    if not os.path.isdir(paths.LIBS_DIR):
        return {}
    for fname in sorted(os.listdir(paths.LIBS_DIR)):
        if fname.lower().endswith(cockz.EXT):
            activate(os.path.join(paths.LIBS_DIR, fname))
    return active()
