"""Zvuk. Player s istim sučeljem na svim OS-ima:

    p = audio.Player();  p.load("pjesma.mp3");  p.play();  p.pause();  p.resume();  p.stop();  p.close()
    p.position()  p.length()  p.volume(0..100)  p.state()  ("playing" | "paused" | "stopped")

Windows: MCI (winmm) - svira mp3, wav, wma, m4a bez ikakvih dodataka.
macOS: afplay.   Linux: mpg123 / ffplay / paplay / aplay (što god je instalirano).
ID3 oznake (naslov, izvođač) čita tags(). Aplikacija treba dozvolu 'audio' (ctx.api.audio).
"""
import os
import shutil
import signal
import subprocess
import sys
import time

from kernel import guard

try:                                   # učitava se prije guarda (helpers.preload); izvan Windowsa ne treba
    import ctypes
except ImportError:                    # pragma: no cover
    ctypes = None

EXTS = (".mp3", ".wav", ".wma", ".m4a", ".aac", ".ogg", ".flac", ".mid", ".mp2")


class AudioError(Exception):
    pass


# ---------------------------------------------------------------- ID3 / trajanje
def _syncsafe(b):
    return (b[0] << 21) | (b[1] << 14) | (b[2] << 7) | b[3]


def _decode_text(data):
    if not data:
        return ""
    enc, body = data[0], data[1:]
    try:
        if enc == 0:
            s = body.decode("latin-1")
        elif enc == 1:
            s = body.decode("utf-16")
        elif enc == 2:
            s = body.decode("utf-16-be")
        else:
            s = body.decode("utf-8")
    except UnicodeDecodeError:
        s = body.decode("latin-1", "replace")
    return s.replace("\x00", "").strip()


def tags(path):
    """{'title','artist','album'} iz ID3v2/ID3v1 (prazno ako ih nema)."""
    out = {"title": "", "artist": "", "album": ""}
    try:
        with open(path, "rb") as f:
            head = f.read(10)
            if head[:3] == b"ID3" and len(head) == 10:
                ver = head[3]
                size = _syncsafe(head[6:10])
                blob = f.read(min(size, 2 * 1024 * 1024))
                pos = 0
                names = {b"TIT2": "title", b"TPE1": "artist", b"TALB": "album"}
                while pos + 10 <= len(blob) and blob[pos] != 0:
                    fid = blob[pos:pos + 4]
                    raw = blob[pos + 4:pos + 8]
                    fsz = _syncsafe(raw) if ver == 4 else int.from_bytes(raw, "big")
                    body = blob[pos + 10:pos + 10 + fsz]
                    if fid in names and not out[names[fid]]:
                        out[names[fid]] = _decode_text(body)
                    if fsz <= 0:
                        break
                    pos += 10 + fsz
            if not out["title"]:
                f.seek(-128, os.SEEK_END)
                v1 = f.read(128)
                if v1[:3] == b"TAG":
                    out["title"] = v1[3:33].split(b"\x00")[0].decode("latin-1").strip()
                    out["artist"] = v1[33:63].split(b"\x00")[0].decode("latin-1").strip()
                    out["album"] = v1[63:93].split(b"\x00")[0].decode("latin-1").strip()
    except (OSError, ValueError):
        pass
    return out


_BR = {1: [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448],
       2: [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384],
       3: [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320]}
_BR_V2 = [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160]
_SR = {3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000]}


def mp3_duration(path):
    """Procjena trajanja mp3-a u sekundama (točna za CBR i Xing/VBR). None ako ne uspije."""
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            head = f.read(10)
            start = 10 + _syncsafe(head[6:10]) if head[:3] == b"ID3" else 0
            f.seek(start)
            buf = f.read(65536)
        for i in range(len(buf) - 4):
            if buf[i] == 0xFF and (buf[i + 1] & 0xE0) == 0xE0:
                b1, b2 = buf[i + 1], buf[i + 2]
                vid, layer = (b1 >> 3) & 3, (b1 >> 1) & 3
                bri, sri = (b2 >> 4) & 15, (b2 >> 2) & 3
                if vid == 1 or layer == 0 or bri in (0, 15) or sri == 3:
                    continue
                layer_n = 4 - layer
                kbps = _BR[layer_n][bri] if vid == 3 else _BR_V2[bri]
                sr = _SR[vid][sri]
                spf = 384 if layer_n == 1 else (1152 if (layer_n == 2 or vid == 3) else 576)
                x = buf.find(b"Xing", i, i + 60)
                if x < 0:
                    x = buf.find(b"Info", i, i + 60)
                if x >= 0 and (buf[x + 7] & 1):
                    frames = int.from_bytes(buf[x + 8:x + 12], "big")
                    return frames * spf / float(sr)
                return (size - start) * 8.0 / (kbps * 1000.0)
    except (OSError, IndexError, KeyError):
        pass
    return None


# ---------------------------------------------------------------- backendi
class _MCI(object):
    name = "Windows MCI (winmm)"
    _n = 0

    def __init__(self):
        _MCI._n += 1
        self.alias = "cockyaudio%d" % _MCI._n
        self.opened = False
        self._vol = 80

    def _cmd(self, text, want=False):
        buf = ctypes.create_unicode_buffer(256)
        err = ctypes.windll.winmm.mciSendStringW(text, buf, 255, 0)
        if err:
            eb = ctypes.create_unicode_buffer(256)
            ctypes.windll.winmm.mciGetErrorStringW(err, eb, 255)
            raise AudioError("MCI: %s" % eb.value)
        return buf.value if want else None

    def load(self, path):
        self.close()
        path = os.path.abspath(path)
        if '"' in path:
            raise AudioError("Unsupported character in file name.")
        kind = " type mpegvideo" if path.lower().endswith((".mp3", ".mp2")) else ""
        self._cmd('open "%s"%s alias %s' % (path, kind, self.alias))
        self.opened = True
        self._cmd("set %s time format milliseconds" % self.alias)
        self.volume(self._vol)

    def play(self):
        self._cmd("play %s from 0" % self.alias)

    def pause(self):
        self._cmd("pause %s" % self.alias)

    def resume(self):
        self._cmd("resume %s" % self.alias)

    def stop(self):
        self._cmd("stop %s" % self.alias)
        self._cmd("seek %s to start" % self.alias)

    def seek(self, seconds):
        was = self.state()
        self._cmd("seek %s to %d" % (self.alias, int(seconds * 1000)))
        if was == "playing":
            self._cmd("play %s" % self.alias)

    def position(self):
        return int(self._cmd("status %s position" % self.alias, True) or 0) / 1000.0

    def length(self):
        return int(self._cmd("status %s length" % self.alias, True) or 0) / 1000.0

    def state(self):
        mode = self._cmd("status %s mode" % self.alias, True)
        return {"playing": "playing", "paused": "paused"}.get(mode, "stopped")

    def volume(self, v):
        self._vol = max(0, min(100, int(v)))
        try:
            self._cmd("setaudio %s volume to %d" % (self.alias, self._vol * 10))
        except AudioError:
            pass

    def close(self):
        if self.opened:
            try:
                self._cmd("close %s" % self.alias)
            except AudioError:
                pass
            self.opened = False


class _Proc(object):
    """macOS / Linux: vanjski program koji svira datoteku. Pauza = SIGSTOP/SIGCONT."""

    def __init__(self, cmd_builder, name):
        self._build = cmd_builder
        self.name = name
        self.proc = None
        self.path = None
        self.t0 = 0.0
        self.acc = 0.0
        self.paused = False
        self._vol = 80
        self._len = None

    def load(self, path):
        self.close()
        self.path = os.path.abspath(path)
        self._len = mp3_duration(path) if path.lower().endswith(".mp3") else None

    def _start(self, offset=0.0):
        self._kill()
        with guard.privileged():
            self.proc = subprocess.Popen(self._build(self.path, self._vol), stdin=subprocess.DEVNULL,
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.t0, self.acc, self.paused = time.time(), offset, False

    def play(self):
        self._start(0.0)

    def pause(self):
        if self.proc and self.proc.poll() is None and not self.paused and hasattr(signal, "SIGSTOP"):
            self.acc += time.time() - self.t0
            os.kill(self.proc.pid, signal.SIGSTOP)
            self.paused = True

    def resume(self):
        if self.proc and self.paused:
            os.kill(self.proc.pid, signal.SIGCONT)
            self.t0, self.paused = time.time(), False

    def _kill(self):
        if self.proc and self.proc.poll() is None:
            if self.paused and hasattr(signal, "SIGCONT"):
                os.kill(self.proc.pid, signal.SIGCONT)
            self.proc.terminate()
            try:
                self.proc.wait(2)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        self.proc, self.paused = None, False

    def stop(self):
        self._kill()
        self.acc = 0.0

    def seek(self, seconds):
        pass                              # nije podržano za vanjske programe

    def position(self):
        if not self.proc:
            return 0.0
        return self.acc + (0 if self.paused else time.time() - self.t0)

    def length(self):
        return self._len or 0.0

    def state(self):
        if not self.proc:
            return "stopped"
        if self.proc.poll() is not None:
            return "stopped"
        return "paused" if self.paused else "playing"

    def volume(self, v):
        self._vol = max(0, min(100, int(v)))      # primjenjuje se pri sljedećem play()

    def close(self):
        self._kill()


def _find_proc_backend():
    if sys.platform == "darwin" and shutil.which("afplay"):
        return lambda: _Proc(lambda p, v: ["afplay", "-v", "%.2f" % (v / 100.0), p], "afplay")
    if shutil.which("mpg123"):
        return lambda: _Proc(lambda p, v: ["mpg123", "-q", "-f", str(int(32768 * v / 100.0)), p], "mpg123")
    if shutil.which("ffplay"):
        return lambda: _Proc(lambda p, v: ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet",
                                           "-volume", str(v), p], "ffplay")
    if shutil.which("paplay"):
        return lambda: _Proc(lambda p, v: ["paplay", p], "paplay")
    if shutil.which("aplay"):
        return lambda: _Proc(lambda p, v: ["aplay", "-q", p], "aplay")
    return None


def _factory():
    if os.name == "nt" and ctypes is not None:
        return _MCI
    return _find_proc_backend()


def backend_name():
    f = _factory()
    if f is None:
        return None
    return f.name if isinstance(f, type) else f().name


class Player(object):
    def __init__(self, backend=None):
        if backend is None:
            f = _factory()
            if f is None:
                raise AudioError("No audio backend found (Linux: install mpg123 or ffplay).")
            backend = f()
        self._b = backend
        self.path = None

    def load(self, path):
        if not os.path.isfile(path):
            raise AudioError("File not found.")
        self._b.load(path)
        self.path = path

    def play(self):
        self._b.play()

    def pause(self):
        self._b.pause()

    def resume(self):
        self._b.resume()

    def toggle(self):
        if self.state() == "playing":
            self.pause()
        elif self.state() == "paused":
            self.resume()
        else:
            self.play()

    def stop(self):
        self._b.stop()

    def seek(self, seconds):
        self._b.seek(max(0.0, seconds))

    def position(self):
        return self._b.position()

    def length(self):
        return self._b.length()

    def state(self):
        return self._b.state()

    def volume(self, v):
        self._b.volume(v)

    def close(self):
        self._b.close()

    @property
    def backend(self):
        return self._b.name
