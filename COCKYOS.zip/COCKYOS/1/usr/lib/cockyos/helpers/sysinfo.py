"""Informacije o sustavu (za About i druge aplikacije)."""
import os
import platform
import shutil
import sys
import time

from kernel import guard, hal, paths, users


def _mem_windows():
    import ctypes

    class MS(ctypes.Structure):
        _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong), ("tp", ctypes.c_ulonglong),
                    ("ap", ctypes.c_ulonglong), ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong),
                    ("tx", ctypes.c_ulonglong), ("ax", ctypes.c_ulonglong), ("ae", ctypes.c_ulonglong)]
    s = MS()
    s.l = ctypes.sizeof(MS)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
    return s.tp, s.ap


def _memory():
    try:
        if os.name == "nt":
            return _mem_windows()
        if os.path.exists("/proc/meminfo"):
            vals = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    k, _, v = line.partition(":")
                    vals[k] = int(v.split()[0]) * 1024
            return vals.get("MemTotal"), vals.get("MemAvailable")
        if sys.platform == "darwin":
            total = int(os.popen("sysctl -n hw.memsize").read().strip())
            return total, None
    except Exception:
        pass
    return None, None


def _uptime():
    try:
        if os.name == "nt":
            import ctypes
            return ctypes.windll.kernel32.GetTickCount64() / 1000.0
        if os.path.exists("/proc/uptime"):
            with open("/proc/uptime") as f:
                return float(f.read().split()[0])
    except Exception:
        pass
    return None


def _cpu():
    try:
        if os.path.exists("/proc/cpuinfo"):
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.lower().startswith("model name"):
                        return line.split(":", 1)[1].strip()
        if os.name == "nt":
            return os.environ.get("PROCESSOR_IDENTIFIER") or platform.processor()
    except Exception:
        pass
    return platform.processor() or platform.machine()


def _tk():
    try:
        import tkinter
        return "Tk %s" % tkinter.TkVersion
    except Exception:
        return None


def collect():
    """Vraća dict s podacima. Čita /proc, ctypes... pa radi u privilegiranom načinu kernela."""
    import kernel
    with guard.privileged():
        mem_total, mem_free = _memory()
        try:
            disk = shutil.disk_usage(paths.PARTITION)
        except OSError:
            disk = None
        from . import libs, audio, imaging
        return {
            "cockyos": kernel.VERSION,
            "partition": paths.PARTITION_NAME,
            "os": hal.NAME,
            "os_detail": platform.platform(),
            "arch": hal.ARCH,
            "runtime_id": hal.RUNTIME_ID,
            "python": platform.python_version(),
            "python_impl": platform.python_implementation(),
            "python_bundled": hal.describe()["bundled_runtime"],
            "cpu": _cpu(),
            "cpu_count": os.cpu_count(),
            "mem_total": mem_total,
            "mem_free": mem_free,
            "disk_total": disk.total if disk else None,
            "disk_free": disk.free if disk else None,
            "uptime": _uptime(),
            "hostname": platform.node(),
            "tk": _tk(),
            "libs": sorted(libs.active()),
            "audio_backend": audio.backend_name(),
            "image_formats": imaging.supported_formats(),
            "users": len(users.get_users()),
            "time": time.strftime("%A, %d.%m.%Y %H:%M:%S"),
        }
