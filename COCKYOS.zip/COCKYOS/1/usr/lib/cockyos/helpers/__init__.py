"""helpers/ - pomoćni kod za KERNEL i za Python ekstenzije (libove) i aplikacije.

    fsx       sigurne putanje i datoteke (safe_join, write_atomic, list_dir...)
    libs      potpisani libovi iz libs/*.cockz (npr. Pillow) -> sys.path
    sysinfo   informacije o OS-u i računalu
    audio     reprodukcija zvuka (Windows: MCI/winmm, macOS: afplay, Linux: mpg123/ffplay/...), ID3 oznake
    imaging   čitanje slika: PNG, GIF, PPM, BMP bez ičega; JPG/WEBP/TIFF uz pillow lib
    ui        Tk pomagala (tema, centriranje, provjera je li Tk dostupan)

Kod u helpers/ i kernel/ je jedini koji smije koristiti `with kernel.guard.privileged():`.
Aplikacije ih dobivaju kroz ctx.api (s provjerom dozvola) ili ih uvoze izravno (guard i dalje vrijedi).
"""


def preload():
    """Učitava helpere (i njihov ctypes) PRIJE nego guard krene, pa ih aplikacije mogu koristiti
    kroz ctx.api, a sama ne mogu uvesti ctypes bez dozvole 'native'."""
    import sys
    from . import fsx, libs, sysinfo, audio, imaging, ui  # noqa: F401
    for name in [m for m in sys.modules if m == "ctypes" or m.startswith("ctypes.") or m == "_ctypes"]:
        del sys.modules[name]          # reference ostaju u helperima; novi `import ctypes` ide kroz guard
