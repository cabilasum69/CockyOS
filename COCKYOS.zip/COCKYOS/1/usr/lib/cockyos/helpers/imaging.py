"""Slike za Tk (i ostale aplikacije).

Bez dodataka: PNG, GIF, PPM/PGM (Tk ih čita sam) i BMP (pretvara se u PNG ovdje).
S libom 'pillow' (potpisani libs/pillow.cockz): i JPG, WEBP, TIFF, ICO...

    img = imaging.load("slika.jpg")   # Image: .width .height .kind .data (bajtovi koje Tk zna čitati)
    img.tk_data()                      # base64 tekst za tkinter.PhotoImage(data=...)
    img.render(Fraction(1, 2))         # (data, w, h) skalirano preko Pillowa, ili None ako Pillowa nema
"""
import base64
import io
import os
import struct
import zlib
from fractions import Fraction

MAX_BYTES = 256 * 1024 * 1024
MAX_PIXELS = 400 * 1000 * 1000
NATIVE = (".png", ".gif", ".ppm", ".pgm", ".bmp")
PILLOW_ONLY = (".jpg", ".jpeg", ".jpe", ".jfif", ".webp", ".tif", ".tiff", ".ico")


class ImageError(Exception):
    pass


def _pillow():
    try:
        from PIL import Image
        return Image
    except Exception:
        return None


def has_pillow():
    return _pillow() is not None


def supported_formats():
    fmts = [e.lstrip(".") for e in NATIVE]
    if has_pillow():
        fmts += [e.lstrip(".") for e in PILLOW_ONLY]
    return fmts


def extensions():
    return NATIVE + (PILLOW_ONLY if has_pillow() else ())


def is_image_name(name):
    return name.lower().endswith(NATIVE + PILLOW_ONLY)


class Image(object):
    def __init__(self, name, width, height, kind, data, pil=None):
        self.name, self.width, self.height, self.kind, self.data, self._pil = name, width, height, kind, data, pil

    def tk_data(self):
        return base64.b64encode(self.data).decode("ascii")

    def render(self, scale):
        """Skalira preko Pillowa (bilo koji omjer). Vraća (png_bajtovi, w, h) ili None bez Pillowa."""
        if self._pil is None:
            return None
        scale = Fraction(scale)
        w = max(1, int(self.width * scale))
        h = max(1, int(self.height * scale))
        im = self._pil
        if (w, h) != im.size:
            im = im.resize((w, h), 1 if scale < 1 else 0)     # LANCZOS-ish za smanjivanje, NEAREST za povećanje
        return _to_png(im), w, h


def _to_png(im):
    mode = "RGBA" if ("A" in im.getbands() or im.mode == "P" and "transparency" in im.info) else "RGB"
    buf = io.BytesIO()
    im.convert(mode).save(buf, "PNG", compress_level=1)
    return buf.getvalue()


# ---------------------------------------------------------------- PNG pisanje (za BMP)
def png_encode(width, height, pixels, channels=3):
    """pixels = bajtovi redak po redak (RGB ili RGBA)."""
    ctype = {3: 2, 4: 6}[channels]
    stride = width * channels
    raw = bytearray()
    for y in range(height):
        raw.append(0)
        raw += pixels[y * stride:(y + 1) * stride]

    def chunk(tag, body):
        c = struct.pack(">I", len(body)) + tag + body
        return c + struct.pack(">I", zlib.crc32(tag + body) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, ctype, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 6)) + chunk(b"IEND", b""))


def bmp_to_png(data):
    """BMP (1/4/8/24/32 bita, bez RLE kompresije) -> (png_bajtovi, w, h)."""
    if len(data) < 30 or data[:2] != b"BM":
        raise ImageError("Not a BMP file.")
    off = struct.unpack_from("<I", data, 10)[0]
    hsize = struct.unpack_from("<I", data, 14)[0]
    if hsize == 12:
        w, h, planes, bpp = struct.unpack_from("<HHHH", data, 18)
        comp, ncol, psz = 0, 0, 3
    else:
        w, h, planes, bpp, comp, _sz, _x, _y, ncol = struct.unpack_from("<iiHHIIiiI", data, 18)
        psz = 4
    topdown = h < 0
    h = abs(h)
    if w <= 0 or h <= 0 or w * h > MAX_PIXELS:
        raise ImageError("Bad BMP size.")
    if comp not in (0, 3):
        raise ImageError("Compressed BMP (RLE) is not supported.")
    if bpp not in (1, 4, 8, 24, 32):
        raise ImageError("BMP with %d bits per pixel is not supported." % bpp)
    stride = ((w * bpp + 31) // 32) * 4
    if off + stride * h > len(data):
        raise ImageError("BMP file is truncated.")
    palette = None
    if bpp <= 8:
        n = ncol or (1 << bpp)
        pal_off = 14 + hsize
        palette = [tuple(data[pal_off + i * psz + 2 - k] for k in range(3)) if pal_off + i * psz + 2 < len(data) else (0, 0, 0)
                   for i in range(n)]
        tr = [bytes([palette[i][c] if i < len(palette) else 0 for i in range(256)]) for c in range(3)]
    channels = 4 if bpp == 32 else 3
    out = bytearray(w * h * channels)
    for row in range(h):
        src_row = row if topdown else h - 1 - row
        raw = data[off + src_row * stride: off + src_row * stride + stride]
        dst = row * w * channels
        if bpp == 24:
            line = raw[:w * 3]
            out[dst + 0:dst + w * 3:3] = line[2::3]
            out[dst + 1:dst + w * 3:3] = line[1::3]
            out[dst + 2:dst + w * 3:3] = line[0::3]
        elif bpp == 32:
            line = raw[:w * 4]
            out[dst + 0:dst + w * 4:4] = line[2::4]
            out[dst + 1:dst + w * 4:4] = line[1::4]
            out[dst + 2:dst + w * 4:4] = line[0::4]
            out[dst + 3:dst + w * 4:4] = b"\xff" * w          # alfa u BMP-u je nepouzdan, pa je neprozirno
        else:
            if bpp == 8:
                idx = raw[:w]
            elif bpp == 4:
                idx = bytearray(w)
                for i in range(w):
                    b = raw[i // 2]
                    idx[i] = (b >> 4) if i % 2 == 0 else (b & 15)
            else:
                idx = bytearray(w)
                for i in range(w):
                    idx[i] = (raw[i // 8] >> (7 - i % 8)) & 1
            idx = bytes(idx)
            out[dst + 0:dst + w * 3:3] = idx.translate(tr[0])
            out[dst + 1:dst + w * 3:3] = idx.translate(tr[1])
            out[dst + 2:dst + w * 3:3] = idx.translate(tr[2])
    return png_encode(w, h, bytes(out), channels), w, h


# ---------------------------------------------------------------- učitavanje
def _png_size(d):
    if len(d) < 24 or d[12:16] != b"IHDR":
        raise ImageError("Damaged PNG.")
    return struct.unpack(">II", d[16:24])


def _gif_size(d):
    if len(d) < 10:
        raise ImageError("Damaged GIF.")
    return struct.unpack("<HH", d[6:10])


def _pnm_size(d):
    parts = d.split(None, 3)
    try:
        return int(parts[1]), int(parts[2])
    except (IndexError, ValueError):
        raise ImageError("Damaged PPM/PGM.")


def load(path):
    """Učita sliku iz datoteke. Baca ImageError s razumljivom porukom ako format nije podržan."""
    name = os.path.basename(path)
    try:
        if os.path.getsize(path) > MAX_BYTES:
            raise ImageError("File is too big.")
        with open(path, "rb") as f:
            d = f.read()
    except OSError as e:
        raise ImageError("Can't read file: %s" % e.strerror)
    if d[:8] == b"\x89PNG\r\n\x1a\n":
        kind, (w, h) = "png", _png_size(d)
    elif d[:6] in (b"GIF87a", b"GIF89a"):
        kind, (w, h) = "gif", _gif_size(d)
    elif d[:2] in (b"P5", b"P6") and len(d) > 3 and d[2:3] in b" \t\r\n":
        kind, (w, h) = "ppm", _pnm_size(d)
    elif d[:2] == b"BM":
        png, w, h = bmp_to_png(d)
        return Image(name, w, h, "png", png, _open_pil(d))
    else:
        Img = _pillow()
        if Img is None:
            raise ImageError("This format needs the 'pillow' lib (see README: tools/wheel2cockz.py). "
                             "Without it only %s work." % ", ".join(sorted(set(e.lstrip(".") for e in NATIVE))))
        try:
            im = Img.open(io.BytesIO(d))
            im.load()
        except Exception as e:
            raise ImageError("Unsupported or damaged image (%s)." % type(e).__name__)
        if im.width * im.height > MAX_PIXELS:
            raise ImageError("Image is too large.")
        return Image(name, im.width, im.height, "png", _to_png(im), im)
    if w * h > MAX_PIXELS:
        raise ImageError("Image is too large.")
    return Image(name, w, h, kind, d, _open_pil(d) if kind in ("png", "gif") else None)


def _open_pil(d):
    Img = _pillow()
    if Img is None:
        return None
    try:
        im = Img.open(io.BytesIO(d))
        im.load()
        return im
    except Exception:
        return None
