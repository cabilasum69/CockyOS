"""Tk pomagala. Tk nije u 'embeddable' Pythonu: tools/add_tk.py ga dodaje u runtime/windows-x64/."""
import os

THEME = {
    "bg": "#121212", "panel": "#1b1b1f", "panel2": "#25252b", "fg": "#e8e8ea", "dim": "#8a8a93",
    "accent": "#00e5ff", "accent2": "#00b0ff", "ok": "#00ff66", "warn": "#ffc107", "bad": "#ff5252",
    "mono": ("Consolas", 10), "ui": ("Segoe UI", 10), "title": ("Segoe UI", 14, "bold"),
}


class TkMissing(Exception):
    pass


def tk_available():
    try:
        import tkinter  # noqa: F401
        import _tkinter  # noqa: F401
        return True
    except Exception:
        return False


def require_tk():
    """Vraća tkinter ili baca TkMissing s uputom što napraviti."""
    try:
        import tkinter
        import _tkinter  # noqa: F401
        return tkinter
    except Exception as e:
        raise TkMissing("Tk is not available in this Python (%s).\n"
                        "Run:  python tools/add_tk.py   (copies Tcl/Tk from a normal Python install into runtime/)." % e)


def center(root, w, h):
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry("%dx%d+%d+%d" % (w, h, (sw - w) // 2, (sh - h) // 3))


def cursor_spec(path):
    """Tk traži '@putanja' s kosim crtama, samo na Windowsu i samo za .cur."""
    if os.name == "nt" and path and path.lower().endswith(".cur") and os.path.isfile(path):
        return "@" + os.path.abspath(path).replace("\\", "/")
    return None


def run_gui(ctx, builder, title=None):
    """Običan okvir za GUI aplikacije: provjeri Tk, napravi prozor, uhvati greške u logu i terminalu."""
    try:
        tk = require_tk()
    except TkMissing as e:
        print("[%s] %s" % (ctx.name, e))
        return 1
    root = tk.Tk()
    if title:
        root.title(title)
    try:
        builder(root, tk)
    except Exception:
        ctx.log.exception("GUI crashed")
        raise
    root.mainloop()
    return 0
