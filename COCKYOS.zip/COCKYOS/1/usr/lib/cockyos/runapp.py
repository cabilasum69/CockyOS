"""Pokreće jednu aplikaciju u zasebnom procesu, uz guard:  python runapp.py <app-id> [user] [args...]

Redoslijed je bitan: kernel i helperi se učitaju PRIJE guarda, pa tek onda kod aplikacije.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
os.environ.setdefault("COCKY_APP_PROCESS", "1")


def _tcl_env():
    """Ako je Tcl/Tk dodan u runtime (tools/add_tk.py), reci Tku gdje su mu skripte."""
    exe_dir = os.path.dirname(os.path.abspath(sys.executable))
    for var, sub in (("TCL_LIBRARY", "tcl8.6"), ("TK_LIBRARY", "tk8.6")):
        for base in (os.path.join(exe_dir, "tcl"), exe_dir):
            d = os.path.join(base, sub)
            if os.path.isdir(d) and var not in os.environ:
                os.environ[var] = d
                break


def main(argv):
    if len(argv) < 2:
        print("usage: runapp.py <app-id> [user] [args...]")
        return 2
    _tcl_env()
    import kernel  # noqa: E402
    kernel.boot(banner=False)
    import helpers  # noqa: E402
    helpers.preload()
    try:
        user = argv[2] if len(argv) > 2 and argv[2] else None
        rc = kernel.apps.launch(argv[1], user, argv[3:])
        return rc if isinstance(rc, int) else 0
    except kernel.apps.AppError as e:
        print("Error: %s" % e)
        return 1
    except PermissionError as e:
        print("Blocked: %s" % e)
        return 3
    except KeyboardInterrupt:
        print("\n(interrupted)")
        return 130
    except Exception as e:
        print("App crashed: %s: %s  (details in log)" % (type(e).__name__, e))
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
